"""Focused API regression tests for the highest-risk ERP business rules.

Run after installing requirements with: python -m unittest discover -s tests -v
These tests are an executable subset; they do not replace the full T-01..T-36 evidence pack.
"""
import os
import tempfile
import unittest

from app import create_app


class ERPAcceptanceTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.previous_db = os.environ.get("DATABASE_PATH")
        self.previous_key = os.environ.get("SECRET_KEY")
        os.environ["DATABASE_PATH"] = os.path.join(self.temp_dir.name, "test_erp.db")
        os.environ["SECRET_KEY"] = "test-secret-key-not-for-deployment"
        self.app = create_app()
        self.app.config.update(TESTING=True)
        self.client = self.app.test_client()
        self.login("owner", "owner123")

    def tearDown(self):
        if self.previous_db is None:
            os.environ.pop("DATABASE_PATH", None)
        else:
            os.environ["DATABASE_PATH"] = self.previous_db
        if self.previous_key is None:
            os.environ.pop("SECRET_KEY", None)
        else:
            os.environ["SECRET_KEY"] = self.previous_key
        self.temp_dir.cleanup()

    def login(self, username, password):
        response = self.client.post("/api/login", json={"username": username, "password": password})
        self.assertEqual(response.status_code, 200, response.get_json())

    def as_role(self, username, password):
        self.client.post("/api/logout")
        self.login(username, password)

    def post(self, path, body=None):
        return self.client.post(path, json=body or {})

    def get(self, path):
        response = self.client.get(path)
        self.assertEqual(response.status_code, 200, response.get_json())
        return response.get_json()

    def test_baseline_and_role_access(self):
        dashboard = self.get("/api/dashboard")
        self.assertEqual(dashboard["on_hand"], 749)
        self.assertEqual(dashboard["reserved"], 10)
        self.assertEqual(dashboard["available"], 739)
        self.assertEqual(dashboard["stock_value"], 6_314_000)
        self.assertEqual(dashboard["open_sales_orders"], 1)
        self.assertEqual(dashboard["open_purchase_orders"], 1)
        self.assertEqual(dashboard["open_leads"], 1)
        customers = self.get("/api/masters/customers")
        c01 = next(row for row in customers if row["code"] == "C01")
        self.assertEqual(c01["credit_exposure"], 566_500)
        self.assertEqual(c01["credit_headroom"], 1_433_500)
        audit_detail = self.get("/api/documents/sales/1")
        self.assertTrue(any(x["relation"] == "Stock Reservation" for x in audit_detail["related_docs"]))
        audit_events = self.get("/api/documents/audit")
        seed_event = next(row for row in audit_events if row["actor"] == "seed" and row["document_ref"] == "S00004")
        self.assertEqual(seed_event["created_at"], "2026-10-01 09:00:00")

        self.as_role("sales", "sales123")
        self.assertEqual(self.client.get("/api/documents/journals").status_code, 403)
        sales_dashboard = self.get("/api/dashboard")
        self.assertNotIn("ar", sales_dashboard)
        self.assertNotIn("stock_value", sales_dashboard)

        self.as_role("warehouse", "warehouse123")
        self.assertEqual(self.client.get("/api/documents/purchase").status_code, 200)

    def test_duplicate_variant_sku_is_rejected(self):
        self.as_role("owner", "owner123")
        response = self.post("/api/products", {
            "sku": "BVG-250-LEM", "name": "Sparkling Lemon", "size": "500 ml",
            "color": "Kuning", "unit": "botol", "sales_price": 25000,
            "standard_cost": 15000, "default_vendor": "V01",
        })
        self.assertEqual(response.status_code, 409)
        self.assertIn("SKU BVG-250-LEM sudah digunakan", response.get_json()["error"])

    def test_credit_limit_and_oversell_are_blocked(self):
        self.as_role("sales", "sales123")
        credit_order = self.post("/api/sales-orders", {
            "customer_code": "C02",
            "warehouse_code": "WH-PKU",
            "lines": [{"sku": "BVG-500-PCH", "quantity": 30}],
        })
        self.assertEqual(credit_order.status_code, 201, credit_order.get_json())
        response = self.post(f"/api/sales-orders/{credit_order.get_json()['id']}/confirm")
        self.assertEqual(response.status_code, 409)
        self.assertIn("Credit limit", response.get_json()["error"])

        stock_order = self.post("/api/sales-orders", {
            "customer_code": "C05",
            "warehouse_code": "WH-PKU",
            "lines": [{"sku": "BVG-250-LEM", "quantity": 45}],
        })
        self.assertEqual(stock_order.status_code, 201, stock_order.get_json())
        response = self.post(f"/api/sales-orders/{stock_order.get_json()['id']}/confirm")
        self.assertEqual(response.status_code, 409)
        self.assertIn("Available stock", response.get_json()["error"])

    def test_order_to_cash_partial_delivery_invoice_and_payment(self):
        self.as_role("sales", "sales123")
        order = self.post("/api/sales-orders", {
            "customer_code": "C01", "warehouse_code": "WH-PKU", "discount_pct": 0,
            "lines": [{"sku": "BVG-250-LEM", "quantity": 8}],
        })
        self.assertEqual(order.status_code, 201, order.get_json())
        order_id = order.get_json()["id"]
        confirmed = self.post(f"/api/sales-orders/{order_id}/confirm")
        self.assertEqual(confirmed.status_code, 200, confirmed.get_json())
        self.assertEqual(confirmed.get_json()["credit_exposure"], 699_700)

        self.as_role("warehouse", "warehouse123")
        delivery = self.post(f"/api/sales-orders/{order_id}/delivery", {"quantities": {"BVG-250-LEM": 6}})
        self.assertEqual(delivery.status_code, 201, delivery.get_json())
        delivery_id = delivery.get_json()["id"]
        validation = self.post(f"/api/deliveries/{delivery_id}/validate")
        self.assertEqual(validation.status_code, 200, validation.get_json())
        self.assertEqual(validation.get_json()["cogs"], 54_000)
        self.assertTrue(self.post(f"/api/deliveries/{delivery_id}/validate").get_json()["idempotent"])

        lemon = [r for r in self.get("/api/stock") if r["sku"] == "BVG-250-LEM" and r["warehouse_code"] == "WH-PKU"][0]
        self.assertEqual((lemon["on_hand"], lemon["reserved"], lemon["available"]), (44, 12, 32))

        self.as_role("finance", "finance123")
        invoice = self.post(f"/api/invoices/from-order/{order_id}")
        self.assertEqual(invoice.status_code, 201, invoice.get_json())
        self.assertEqual((invoice.get_json()["net"], invoice.get_json()["tax"], invoice.get_json()["total"]), (90_000, 9_900, 99_900))
        invoice_id = invoice.get_json()["id"]
        self.assertEqual(self.post(f"/api/invoices/{invoice_id}/post").status_code, 200)
        self.assertTrue(self.post(f"/api/invoices/{invoice_id}/post").get_json()["idempotent"])
        payment_payload = {"document_type": "customer", "document_id": invoice_id, "amount": 40_000, "idempotency_key": "customer-payment-t27"}
        payment = self.post("/api/payments", payment_payload)
        self.assertEqual(payment.status_code, 201, payment.get_json())
        self.assertEqual(payment.get_json()["residual"], 59_900)
        repeated = self.post("/api/payments", payment_payload)
        self.assertTrue(repeated.get_json()["idempotent"])
        self.assertEqual(self.post("/api/payments", {"document_type": "customer", "document_id": invoice_id, "amount": 110_000}).status_code, 409)
        self.assertTrue(self.get("/api/accounting/trial-balance")["balanced"])
        self.assertEqual(self.get("/api/dashboard")["ar"], 1_109_900)

    def test_procure_to_pay_quality_grni_and_three_way_match(self):
        po = self.get("/api/documents/purchase")[0]
        self.as_role("warehouse", "warehouse123")
        receipt = self.post(f"/api/purchase-orders/{po['id']}/receipt", {
            "warehouse_code": "WH-PKU",
            "lines": [{"sku": "BVG-500-LEM", "received_qty": 12}],
        })
        self.assertEqual(receipt.status_code, 201, receipt.get_json())
        receipt_id = receipt.get_json()["id"]

        self.as_role("quality", "quality123")
        qc = self.post(f"/api/receipts/{receipt_id}/quality-check", {
            "sku": "BVG-500-LEM", "accepted_qty": 10, "rejected_qty": 2, "quality_reason": "Segel rusak",
        })
        self.assertEqual(qc.status_code, 200, qc.get_json())

        self.as_role("warehouse", "warehouse123")
        self.assertEqual(self.post(f"/api/receipts/{receipt_id}/validate").status_code, 200)
        lemon500 = [r for r in self.get("/api/stock") if r["sku"] == "BVG-500-LEM" and r["warehouse_code"] == "WH-PKU"][0]
        self.assertEqual(lemon500["on_hand"], 40)

        self.as_role("finance", "finance123")
        bill = self.post(f"/api/vendor-bills/from-receipt/{receipt_id}")
        self.assertEqual(bill.status_code, 201, bill.get_json())
        self.assertEqual((bill.get_json()["net"], bill.get_json()["tax"], bill.get_json()["total"]), (150_000, 16_500, 166_500))
        bill_id = bill.get_json()["id"]
        self.assertEqual(self.post(f"/api/vendor-bills/{bill_id}/post").status_code, 200)
        self.assertTrue(self.post(f"/api/vendor-bills/{bill_id}/post").get_json()["idempotent"])
        self.assertEqual(self.get("/api/dashboard")["ap"], 386_500)
        self.assertTrue(self.get("/api/accounting/trial-balance")["balanced"])

    def test_large_purchase_order_requires_explicit_owner_approval(self):
        self.as_role("procurement", "procurement123")
        po = self.post("/api/purchase-orders", {
            "vendor_code": "V01", "lines": [{"sku": "BVG-500-LEM", "quantity": 70}],
        })
        self.assertEqual(po.status_code, 201, po.get_json())
        po_id = po.get_json()["id"]
        pending = self.post(f"/api/purchase-orders/{po_id}/confirm")
        self.assertEqual(pending.status_code, 200)
        self.assertEqual(pending.get_json()["status"], "Pending Approval")
        self.as_role("owner", "owner123")
        approved = self.post(f"/api/purchase-orders/{po_id}/approve")
        self.assertEqual(approved.status_code, 200, approved.get_json())
        self.assertEqual(approved.get_json()["status"], "Confirmed")

    def test_vendor_bill_mismatch_above_accepted_quantity_is_flagged_and_blocked(self):
        po = self.get("/api/documents/purchase")[0]
        self.as_role("warehouse", "warehouse123")
        receipt = self.post(f"/api/purchase-orders/{po['id']}/receipt", {
            "warehouse_code": "WH-PKU",
            "lines": [{"sku": "BVG-500-LEM", "received_qty": 12}],
        }).get_json()
        self.as_role("quality", "quality123")
        self.assertEqual(self.post(f"/api/receipts/{receipt['id']}/quality-check", {
            "sku": "BVG-500-LEM", "accepted_qty": 10, "rejected_qty": 2, "quality_reason": "Segel rusak",
        }).status_code, 200)
        self.as_role("warehouse", "warehouse123")
        self.assertEqual(self.post(f"/api/receipts/{receipt['id']}/validate").status_code, 200)
        self.as_role("finance", "finance123")
        bill = self.post(f"/api/vendor-bills/from-receipt/{receipt['id']}", {
            "lines": [{"sku": "BVG-500-LEM", "quantity": 12}],
        })
        self.assertEqual(bill.status_code, 201, bill.get_json())
        self.assertEqual(bill.get_json()["match_status"], "Mismatch")
        self.assertIn("selisih 2", bill.get_json()["match_details"])
        blocked = self.post(f"/api/vendor-bills/{bill.get_json()['id']}/post")
        self.assertEqual(blocked.status_code, 409)
        self.assertEqual(blocked.get_json()["match_status"], "Mismatch")

    def test_internal_transfer_is_validated_once(self):
        self.as_role("warehouse", "warehouse123")
        transfer = self.post("/api/transfers", {
            "sku": "TEA-350-ORI", "quantity": 5, "from_warehouse": "WH-PKU", "to_warehouse": "OUT-MRP",
        })
        self.assertEqual(transfer.status_code, 201, transfer.get_json())
        transfer_id = transfer.get_json()["id"]
        self.assertEqual(self.post(f"/api/transfers/{transfer_id}/validate").status_code, 200)
        second = self.post(f"/api/transfers/{transfer_id}/validate")
        self.assertTrue(second.get_json()["idempotent"])
        rows = self.get("/api/stock")
        wh = [r for r in rows if r["sku"] == "TEA-350-ORI" and r["warehouse_code"] == "WH-PKU"][0]
        out = [r for r in rows if r["sku"] == "TEA-350-ORI" and r["warehouse_code"] == "OUT-MRP"][0]
        self.assertEqual((wh["on_hand"], out["on_hand"]), (55, 23))

    def test_return_creates_credit_note_and_reverses_cogs(self):
        self.as_role("sales", "sales123")
        order = self.post("/api/sales-orders", {
            "customer_code": "C01", "warehouse_code": "WH-PKU", "lines": [{"sku": "BVG-250-LEM", "quantity": 6}],
        }).get_json()
        self.assertEqual(self.post(f"/api/sales-orders/{order['id']}/confirm").status_code, 200)
        self.as_role("warehouse", "warehouse123")
        delivery = self.post(f"/api/sales-orders/{order['id']}/delivery", {"quantities": {"BVG-250-LEM": 6}}).get_json()
        self.assertEqual(self.post(f"/api/deliveries/{delivery['id']}/validate").status_code, 200)
        self.as_role("finance", "finance123")
        invoice = self.post(f"/api/invoices/from-order/{order['id']}").get_json()
        self.assertEqual(self.post(f"/api/invoices/{invoice['id']}/post").status_code, 200)
        self.as_role("warehouse", "warehouse123")
        returned = self.post("/api/returns", {
            "invoice_id": invoice["id"], "sku": "BVG-250-LEM", "quantity": 2, "inspection_status": "Saleable",
        })
        self.assertEqual(returned.status_code, 201, returned.get_json())
        return_id = returned.get_json()["id"]
        self.as_role("finance", "finance123")
        credit = self.post(f"/api/returns/{return_id}/validate")
        self.assertEqual(credit.status_code, 200, credit.get_json())
        self.assertEqual((credit.get_json()["net_amount"], credit.get_json()["tax_amount"], credit.get_json()["total"]), (30_000, 3_300, 33_300))
        self.assertEqual(credit.get_json()["cogs_reversal"], 18_000)
        self.assertTrue(self.post(f"/api/returns/{return_id}/validate").get_json()["idempotent"])
        self.assertTrue(self.get("/api/accounting/trial-balance")["balanced"])


if __name__ == "__main__":
    unittest.main()
