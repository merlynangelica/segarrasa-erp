# SegarRasa ERP — PT Segar Rasa Riau

Aplikasi web ERP mandiri untuk studi kasus distributor minuman kemasan dan camilan PT Segar Rasa Riau. Navigasi desktop dan pola dokumen mengambil inspirasi dari Odoo Web 17, tetapi aplikasi ini **bukan Odoo** dan tidak menyalin source code maupun aset Odoo.

## Teknologi

- Python 3.11+
- Flask 3
- SQLite dengan migrasi skema yang bersifat additive
- HTML, CSS, dan Vanilla JavaScript
- Session authentication dan role-based access control (RBAC)

## Menjalankan aplikasi secara lokal

1. Extract ZIP, lalu buka folder project `segarrasa-erp-main` di VS Code.
2. Buat virtual environment:
   ```bash
   python -m venv .venv
   ```
3. Aktifkan environment:
   - Windows PowerShell: `.venv\\Scripts\\Activate.ps1`
   - macOS/Linux: `source .venv/bin/activate`
4. Install dependency:
   ```bash
   pip install -r requirements.txt
   ```
5. Salin `env.example` menjadi `.env`. Untuk penggunaan nyata, ganti `SECRET_KEY` dengan nilai acak yang kuat.
6. Jalankan:
   ```bash
   python run.py
   ```
7. Buka `http://127.0.0.1:5000`.

Database default dibuat pada `instance/segarrasa_erp.db`. Folder `instance/` dikecualikan dari repository agar database lokal tidak ikut terunggah. Seed awal dimuat otomatis ketika database belum memiliki user.

## Akun uji bawaan

Seed awal membuat enam akun sesuai role aplikasi. Kredensial ini untuk pengujian kelas; ganti sebelum aplikasi dipublikasikan di internet dan bagikan kredensial final kepada dosen melalui kanal penyerahan yang sesuai.

| Role | Username | Password awal |
|---|---|---|
| Owner | `owner` | `owner123` |
| Sales | `sales` | `sales123` |
| Warehouse | `warehouse` | `warehouse123` |
| Procurement | `procurement` | `procurement123` |
| Finance | `finance` | `finance123` |
| Quality | `quality` | `quality123` |

## Cakupan implementasi

### Data baseline

- 6 customer, 4 vendor, 15 variant SKU, dan 2 lokasi: `WH-PKU` serta `OUT-MRP`.
- Opening stock 749 unit, reservation S00004 sebanyak 10 unit, Available agregat 739 unit.
- Nilai persediaan awal Rp6.314.000, opening AR Rp1.050.000, opening AP Rp220.000, dan Bank Rp7.000.000.
- Dokumen awal CRM00009, S00004, dan PO00003.
- Pajak simulasi efektif 11% dan pembulatan half-up per invoice line.

### Alur utama yang sudah disediakan

**Order to Cash:** Sales Order → reservation → Delivery / backorder → Customer Invoice berdasarkan delivered quantity → posting jurnal → partial/full payment. CRM Lead → Quotation → konversi menjadi SO juga tersedia.

**Procure to Pay:** RFQ / Purchase Order → approval Owner untuk subtotal di atas Rp1.000.000 → Receipt → Quality Pass/Fail → accepted quantity masuk stok dan GRNI → Vendor Bill dari accepted quantity → three-way match → payment.

**Alur lintas modul:** internal transfer dua lokasi, return inspection, stock return untuk barang saleable, Credit Note dan pembalikan COGS, dashboard role-aware, trial balance, audit log, related-document drill-through, dan idempotency guard untuk posting/validasi/payment/return.

### Role aplikasi

- **Sales:** CRM, customer/product view, quotation/SO, dan status penjualan.
- **Warehouse:** inventory, delivery, receipt, internal transfer, dan penerimaan retur fisik.
- **Procurement:** vendor, RFQ/PO, serta status Receipt/Vendor Bill yang relevan.
- **Quality:** pemeriksaan Receipt Pass/Fail dan alasan barang ditolak.
- **Finance:** Customer Invoice, Vendor Bill, payment, return/Credit Note posting, jurnal, dan laporan.
- **Owner:** akses penuh termasuk approval PO dan reset baseline.

API permission adalah batas keamanan utama; menyembunyikan menu pada frontend saja tidak dianggap sebagai otorisasi.

## Menggunakan workflow pada UI

Sebagian aksi ditampilkan sebagai tombol workflow di halaman modul. Untuk menjaga perubahan tetap kecil terhadap frontend awal kelompok, beberapa aksi masih menggunakan prompt untuk memasukkan database ID atau kuantitas. ID yang dibutuhkan adalah kolom `id` pada List View, bukan nomor dokumen seperti `S00005`.

Alur praktis demo:

1. Sales: buat SO, lalu Confirm SO.
2. Warehouse: buat Delivery dari SO, lalu Validate Delivery.
3. Finance: buat invoice dari SO yang sudah dikirim, lalu Post Invoice dan catat payment.
4. Procurement: buat RFQ/PO, lalu minta Confirm. PO besar akan menjadi `Pending Approval`.
5. Owner: buka Purchase dan lakukan approval untuk PO besar.
6. Warehouse: buat Receipt dari PO yang sudah Confirmed.
7. Quality: catat jumlah Pass/Fail dan alasan Fail.
8. Warehouse: Validate Receipt.
9. Finance: buat Vendor Bill dari Receipt yang sudah Done, Post Vendor Bill, lalu catat payment.
10. Untuk retur, Warehouse mencatat inspeksi dan Finance mem-post Credit Note.

List View, Kanban, Form detail, dan Activity entry tersedia sebagai pola navigasi tambahan. Form detail membutuhkan satu baris yang dipilih dari List View. Beberapa layar tetap berupa daftar ringkas dan belum menyamai seluruh kedalaman tampilan Odoo.

## Pengujian

Regression API untuk alur berisiko tinggi tersedia pada:

```bash
python -m unittest discover -s tests -v
```

Test suite tersebut mencakup baseline dan RBAC, credit gate/overselling, Order to Cash dengan partial delivery dan payment, Procure to Pay dengan Quality/GRNI/three-way match, approval PO besar, internal transfer idempotent, serta return/Credit Note.

**Penting:** test suite ini adalah subset otomatis, bukan bukti bahwa seluruh T-01 sampai T-36 sudah lulus. Tim tetap wajib menjalankan seluruh T-01–T-36 dari handout, mengisi Expected, Actual, Pass/Fail, dan menyimpan screenshot/bukti sesuai `docs/TEST_RESULTS_TEMPLATE.md`. Jangan mengubah status menjadi Pass sebelum benar-benar dijalankan pada aplikasi.

## Dokumen project dan bukti penyerahan

- `PDF_SCOPE.md` — ringkasan cakupan dari handout.
- `docs/MODIFICATION_SUMMARY.md` — area yang dilanjutkan, pemeriksaan statis, dan batasan yang masih harus diselesaikan.
- `REQUIREMENTS_TRACEABILITY.md` — hubungan requirement dan implementasi.
- `DATA_MODEL.md` — ringkasan model data.
- `docs/DECISION_LOG.md` — keputusan bisnis dan trade-off yang perlu dikonfirmasi tim.
- `docs/TEST_RESULTS_TEMPLATE.md` — lembar pencatatan T-01 sampai T-36.
- `tests/test_erp_acceptance.py` — subset regression test API.

Sebelum penyerahan, lengkapi juga Role Assignment Sheet, Team Agreement, AI-tool usage note, contribution table, commit history semua anggota, diagram arsitektur/data, README final, URL publik, akun uji semua role, video demo maksimal 10 menit, dan slide presentasi 15 menit + Q&A 10 menit.

## Deployment publik

`run.py` menerima `HOST` dan `PORT` dari environment dan default bind ke `0.0.0.0`, tetapi menjalankan server development Flask. Untuk deployment publik gunakan WSGI server yang sesuai platform hosting, nonaktifkan debug, atur `SECRET_KEY` yang kuat, aktifkan `SESSION_COOKIE_SECURE=1` jika sudah memakai HTTPS, serta pastikan lokasi database berada pada persistent disk. Hosting dengan filesystem sementara dapat menghilangkan database saat restart/deploy.

Contoh environment produksi:

```env
SECRET_KEY=<random-secret-yang-kuat>
DATABASE_PATH=/path/ke/persistent-disk/segarrasa_erp.db
FLASK_DEBUG=0
SESSION_COOKIE_SECURE=1
HOST=0.0.0.0
PORT=5000
```

Project pada ZIP ini belum memiliki URL publik yang sudah dideploy. Deployment dan verifikasi akses dari jaringan luar tetap harus dilakukan oleh kelompok pada akun hosting milik tim.
