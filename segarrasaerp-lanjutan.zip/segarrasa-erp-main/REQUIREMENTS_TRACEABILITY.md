# Requirement Traceability — PT Segar Rasa Riau

Status pada kolom terakhir menunjukkan cakupan kode yang disediakan, bukan hasil test dosen. Seluruh baris tetap membutuhkan eksekusi test T terkait dan bukti aktual.

| Requirement / Feature | Implementasi yang tersedia | Test rujukan | Status kode |
|---|---|---|---|
| SR-01 / SR-02, F-05/F-08/F-09 | SO; delivery parsial; invoice dibatasi pada delivered quantity yang belum ditagih | T-09–10, T-13–16 | Implemented; verify |
| SR-03 / SR-04, F-07 | Reservation dan Available = On Hand − Reserved; delivery/transfer memeriksa Available serta reservasi order | T-11–12, T-29–30 | Implemented; verify |
| SR-05 / SR-06, F-11/F-12/F-14 | Vendor pricelist; Receipt; accepted/rejected quantity; Vendor Bill dapat merekam qty tagihan vendor; mismatch PO–Receipt–Bill ditandai dan posting diblokir; GRNI clearing | T-17–24 | Implemented; verify |
| SR-07 / SR-08, F-06 | Diskon >10% dibatasi ke Owner; SO Confirmed terkunci; revisi terkontrol dicatat di audit | T-09–10 | Partial: revision hanya merekam permintaan, tidak mengubah nilai komersial |
| SR-09 / F-02/F-10 | Contact menampilkan opening AR, residual invoice, Confirmed SO uninvoiced, credit exposure, dan headroom; confirm memblokir bila melewati limit | T-03–04, T-11–12 | Implemented; verify |
| SR-10 / F-16 | Customer/vendor partial payment, residual, status Partial/Paid, jurnal pasangan | T-27–28 | Implemented; verify |
| SR-11 / F-13 | QC Pass/Fail per line, alasan Fail, actor/time; rejected tidak masuk sellable stock | T-19–22 | Implemented; verify |
| SR-12 / F-17 | Internal transfer Ready → Done, Available check, idempotent validation | T-29–30 | Implemented; verify |
| SR-13 / F-18 | Return inspection, return cap, stock return jika Saleable, Credit Note, reversal VAT/AR/COGS | T-31–32 | Implemented; verify |
| SR-14 / F-21 | PPN efektif 11%, ROUND_HALF_UP pada level invoice line | T-09, T-15–16, T-17, T-23 | Implemented; verify |
| SR-15 / F-15/F-20 | Sequence, audit actor/action/reference, timestamp fixture S00004, balanced journal helper, atomic write lock, status guard, idempotency key untuk payment/return | T-25–26, T-35–36 | Implemented; verify |
| SR-16 / F-01 | 6 role, API permission check, Sales ditolak dari journal/ledger; dashboard dibatasi per role | T-01–02 | Implemented; verify |
| SR-17 / F-03 | 15 SKU unik; endpoint tambah variant Owner-only menolak SKU duplikat, membuat stok awal nol pada dua lokasi | T-05–06 | Implemented; verify |
| SR-18 / F-04 | Lead stage, quotation, conversion to SO, audit relation | T-07–08 | Implemented; verify |
| SR-19 / F-19 | Dashboard KPI role-aware, revenue hanya invoice posted dikurangi Credit Note posted, detail dokumen menyediakan related-document links | T-33–35 | Partial: seluruh KPI drill-through/interaksi perlu diverifikasi |
| SR-20 / F-22 | PO subtotal > Rp1.000.000 masuk Pending Approval; endpoint approval Owner terpisah | T-17–18 | Implemented; verify |
| F-01–F-22 | Modul dan workflow dari handout | T-01–T-36 | Belum disertifikasi; bukti aktual wajib |
| F-23 | Lot/expiry tracking | Optional | Tidak diimplementasikan; boleh ditunda |

## Catatan implementasi penting

- Migrasi database hanya menambah kolom/index/tabel dan tidak melakukan drop/rebuild tabel kelompok.
- `workflows.js` ditambahkan sebagai layer tambahan agar `app.js` awal kelompok tetap dipertahankan.
- UI beberapa aksi memakai prompt dan database ID. Ini mempermudah workflow terhubung, tetapi belum setara dengan Form View lengkap Odoo.
- Posting jurnal memakai helper yang menolak jurnal tidak balance dan mengecek sumber jurnal yang sudah diposting.
- Customer Contact menampilkan breakdown credit exposure. Vendor Bill dapat menyimpan permintaan tagihan 12 unit untuk Receipt dengan 10 accepted; mismatch direkam dan posting ditolak (T-24).
- Detail dokumen menyediakan relasi dokumen terkait. Payment dan return menerima `idempotency_key` agar request retry identik tidak membuat jurnal/stock move kedua.
- Tidak ada klaim T-01 sampai T-36 lulus sampai tim mengisi bukti aktual.
