# Data Model — SegarRasa ERP

Database relasional SQLite; semua koneksi mengaktifkan foreign key. Nilai uang disimpan sebagai integer Rupiah. Setiap variant SKU merupakan record produk tersendiri dan stok disimpan per kombinasi SKU + warehouse.

## Master dan setup

- `users`, `customers`, `vendors`, `products`, `vendor_pricelist`, `warehouses`, `stock`, `reservations`, `settings`, `sequences`, `reorder_points`.
- Customer menyimpan credit limit, payment terms, dan opening AR. Vendor menyimpan payment terms, tax status, dan opening AP.
- `vendor_pricelist` mengikat vendor–SKU, minimum quantity, purchase price, dan currency.

## Sales / CRM

- `leads` → `quotations` / `quotation_lines` → `sales_orders` / `sales_order_lines` → `deliveries` / `delivery_lines` → `invoices` / `invoice_lines`.
- SO menyimpan referensi optional ke Quotation. Reservation menyimpan dokumen sumber, SKU, warehouse, quantity, dan status active.
- `sales_order_revisions` menyimpan actor, reason, dan snapshot sebelum/sesudah untuk permintaan revisi yang dikontrol.

## Purchase / Inventory / Quality

- `purchase_orders` / `purchase_order_lines` → `receipts` / `receipt_lines`.
- Receipt line menyimpan inspected/accepted/rejected quantity, fail reason, inspector, dan timestamp QC.
- `vendor_bills` / `vendor_bill_lines` berasal dari accepted Receipt quantity. GRNI ditampung di akun 1210 sampai Vendor Bill diposting.
- `transfers` memindahkan stok antarlokasi; `returns` menyimpan inspeksi retur dan `credit_notes` menyimpan pembalikan tagihan.

## Accounting / audit

- `journal_entries` / `journal_lines` menyimpan source document dan baris Debit/Credit.
- `payments` menyimpan pembayaran customer atau vendor; status dokumen menjadi Partial/Paid sesuai residual.
- `credit_notes` terhubung satu-ke-satu dengan return; journal source menghubungkan posting ke dokumen asal.
- `audit_logs` mencatat actor, action, document reference, details, dan timestamp.

## Chart of Accounts dari handout

1010 Bank, 1020 Cash on Hand, 1100 Accounts Receivable, 1200 Stock Valuation, 1210 GRNI, 1300 VAT Input, 2100 Accounts Payable, 2200 VAT Output, 3100 Opening Equity, 4100 Sales Revenue, 4110 Sales Discounts, 5100 COGS, 6100 Quality Loss, 6200 Shipping Expense, 6300 Bank Charges.

## Integrity notes

- Money = integer IDR; effective VAT = 11%; rounding half-up per invoice line.
- Standard cost digunakan untuk stock valuation dan COGS dalam simulasi handout.
- `BEGIN IMMEDIATE` digunakan pada operasi read-check-write utama untuk mengurangi race condition stok dan posting.
- Migrations bersifat additive: tabel/kolom/index ditambahkan dan data existing tidak di-drop.
