# Source Basis and Project Scope

This project follows the supplied 36-page handout: *Student Scenario Handout — PT Segar Rasa Riau*.

Source-derived facts encoded in the seed/config:
- PT Segar Rasa Riau / SegarRasa, Pekanbaru, IDR.
- Warehouses WH-PKU and OUT-MRP.
- Six application roles: Sales, Warehouse, Procurement, Finance, Quality, Owner.
- Six customers, four vendors, fifteen product variant SKUs.
- Baseline stock 749 units (WH-PKU 596, OUT-MRP 153), baseline reserved 10 units on S00004, available 739.
- Opening balances: AR Rp1.050.000, AP Rp220.000, Bank Rp7.000.000, Inventory Rp6.314.000; opening journal balances.
- Effective simulated VAT 11% = nominal 12% × 11/12, rounded half-up per invoice line.
- SR-01–SR-20, F-01–F-22, screens S-01–S-18 and tests T-01–T-36 are the assignment requirement set.

Implementation choices:
- Flask + SQLite + Vanilla JS; technology is team-selectable per handout.
- API permission map, sequence prefixes, additive schema migrations, and two-step Quality / Return validation.
- Large purchase orders require a separate Owner approval action.
- Accounting postings use the provided chart-of-accounts codes.

Important completion state:
- Code coverage has been extended, but the app is not yet publicly deployed from this workspace.
- Automated regression tests are included for key end-to-end cases, but they still must be run in an environment with dependencies installed.
- The full T-01–T-36 test evidence pack must be executed and completed by the group; see `docs/TEST_RESULTS_TEMPLATE.md`.
- Any remaining partial item is listed in `REQUIREMENTS_TRACEABILITY.md` and `README.md`.
