# Application Architecture

```mermaid
flowchart TD
  U[Desktop Browser] --> UI[HTML / CSS / Vanilla JavaScript]
  UI --> API[Flask JSON API]
  API --> AUTH[Session + RBAC]
  AUTH --> SVC[Sales / CRM / Purchase / Inventory / Quality / Accounting workflows]
  SVC --> DB[(SQLite persistent database)]
  SVC --> AUD[Audit events]
  SVC --> GL[Journal entries / lines]
  AUD --> DB
  GL --> DB
```

## Cross-module flow

```mermaid
flowchart LR
  CRM[Lead / Opportunity] --> Q[Quotation] --> SO[Sales Order]
  SO --> RES[Reservation] --> DO[Delivery]
  DO --> INV[Customer Invoice] --> PAY[Customer Payment]
  PO[RFQ / Purchase Order] --> R[Receipt]
  R --> QC[Quality Pass / Fail]
  QC --> ST[Accepted stock + GRNI]
  ST --> VB[Vendor Bill / Three-way Match] --> VP[Vendor Payment]
  INV --> RET[Return Inspection] --> CN[Credit Note + AR / COGS reversal]
```

The browser is a presentation layer; API permission checks are authoritative. SQLite persists transactional and audit records. This diagram describes the current Flask implementation and should be updated if the deployed architecture changes.
