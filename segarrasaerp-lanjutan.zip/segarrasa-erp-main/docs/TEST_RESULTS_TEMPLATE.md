# Test Results — T-01 sampai T-36

**Aturan:** setiap test dimulai dari baseline seed baru kecuali handout secara eksplisit menyebut `After T-xx (fixture)`. Jangan mengisi Pass tanpa menjalankan test dan menyimpan bukti. Status awal setiap test adalah `Not Run`.

Isi format per test: **Actual Result**, **Status (Pass/Fail/Blocked/Not Run)**, **Evidence filename/link**, **Defect ID**, **Tester**, dan **Tanggal/Waktu**.

| Test | Jenis | Expected result / fokus pengujian | Actual result | Status | Evidence |
|---|---|---|---|---|---|
| T-01 | Normal | Login Sales dan Owner; app/menu sesuai izin; Sales tidak dapat melakukan aksi ledger | — | Not Run | — |
| T-02 | Edge | Sales mengakses URL Journal Entry secara langsung; harus denied/403 tanpa isi ledger | — | Not Run | — |
| T-03 | Normal | C01: opening AR Rp400.000 + S00004 uninvoiced gross Rp166.500 = exposure Rp566.500; headroom Rp1.433.500 | — | Not Run | — |
| T-04 | Edge | C02 AR Rp650.000 + pesanan 30 × BVG-500-PCH @Rp26.000; exposure Rp1.515.800 melebihi limit Rp1.000.000; SO tertahan | — | Not Run | — |
| T-05 | Normal | 15 SKU tersedia; BVG-250-LEM price Rp15.000/cost Rp9.000 dan BVG-500-LEM price Rp25.000/cost Rp15.000 | — | Not Run | — |
| T-06 | Edge | SKU BVG-250-LEM tidak boleh digunakan ulang untuk variant ukuran lain | — | Not Run | — |
| T-07 | Normal | CRM00009 pindah Qualified → Won; revenue/jurnal baru tetap Rp0 | — | Not Run | — |
| T-08 | Edge | CRM00009 dapat dibuat Quotation terkait; tidak membuat jurnal penjualan | — | Not Run | — |
| T-09 | Normal | SO C01 8 × BVG-250-LEM: net Rp120.000, PPN Rp13.200, gross Rp133.200; exposure C01 menjadi Rp699.700 | — | Not Run | — |
| T-10 | Edge | Diskon 20% tanpa Owner approval tertahan; harga/diskon pada SO Confirmed tidak dapat diedit langsung | — | Not Run | — |
| T-11 | Normal | BVG-250-LEM WH: On Hand 50, Reserved 10, Available 40; confirm SO baru 8 menjadi 50/18/32 | — | Not Run | — |
| T-12 | Edge | Pesanan 45 Lemon 250 ml untuk C05 tidak boleh menghabiskan stok yang Available hanya 40 | — | Not Run | — |
| T-13 | Normal | SO 8 unit; Delivery 6: Delivered 6, Backorder 2; WH On Hand 44, Reserved 12, Available 32; COGS Rp54.000 | — | Not Run | — |
| T-14 | Edge | Invoice untuk 8 unit setelah hanya 6 dikirim dibatasi maksimal 6 unit | — | Not Run | — |
| T-15 | Normal | Invoice untuk 6 Lemon: net Rp90.000, PPN Rp9.900, total Rp99.900; AR aggregate Rp1.149.900 sebelum pembayaran | — | Not Run | — |
| T-16 | Edge | SO Confirmed tetapi belum ada Delivery Done: invoicable quantity 0; tidak ada AR/jurnal | — | Not Run | — |
| T-17 | Normal | PO00003 12 × BVG-500-LEM: net Rp180.000, PPN Rp19.800, gross Rp199.800; stock tetap 749 | — | Not Run | — |
| T-18 | Edge | PO 70 × BVG-500-LEM subtotal Rp1.050.000; Procurement tidak dapat confirm sebelum Owner approval | — | Not Run | — |
| T-19 | Normal | PO00003 receipt 12; Pass 10/Fail 2; WH Lemon 500 ml naik 30→40; valuation naik Rp150.000 | — | Not Run | — |
| T-20 | Edge | Receipt 13 terhadap PO qty12 harus ditolak / meminta revisi PO | — | Not Run | — |
| T-21 | Normal | QC mencatat Inspected12, Passed10, Failed2, alasan Fail; rejected value Rp30.000 tidak masuk stok | — | Not Run | — |
| T-22 | Edge | 2 unit Fail tidak dapat diubah menjadi Accepted tanpa koreksi Quality yang diaudit | — | Not Run | — |
| T-23 | Normal | Vendor Bill hanya 10 accepted × Rp15.000; net Rp150.000, PPN Rp16.500, gross/AP Rp166.500; GRNI dibersihkan | — | Not Run | — |
| T-24 | Edge | Vendor Bill 12 unit meskipun accepted hanya10 harus ditahan; selisih2 ditandai dan tidak diposting | — | Not Run | — |
| T-25 | Normal | Delivery 6 Lemon; Dr COGS Rp54.000 dan Cr Inventory Rp54.000; debit=credit | — | Not Run | — |
| T-26 | Edge | Validate ulang Delivery Done tidak membuat journal/stock move/pengurangan stok kedua | — | Not Run | — |
| T-27 | Normal | Payment customer Rp40.000 atas invoice Rp99.900; residual Rp59.900; Bank Rp7.040.000; invoice Partial | — | Not Run | — |
| T-28 | Edge | Payment negatif/nol atau Rp110.000 atas residual Rp99.900 ditolak; GL tidak berubah | — | Not Run | — |
| T-29 | Normal | Transfer 5 TEA-350-ORI: WH 60→55, OUT 18→23, total tetap78 dan nilai agregat sama | — | Not Run | — |
| T-30 | Edge | Validate ulang transfer Done tidak memindahkan 5 unit untuk kedua kalinya | — | Not Run | — |
| T-31 | Normal | Return 2 dari 6 Lemon saleable: Credit Note net Rp30.000 + PPN Rp3.300 = Rp33.300; stock +2; COGS reversal Rp18.000 | — | Not Run | — |
| T-32 | Edge | Return 7 dari 6 delivered ditolak; posting Credit Note kedua tidak menggandakan AR/jurnal | — | Not Run | — |
| T-33 | Normal | Baseline dashboard: On Hand749, Reserved10, Available739, valuation Rp6.314.000, 1 open SO, 1 open PO, 1 open Lead | — | Not Run | — |
| T-34 | Edge | S00004 Confirmed tetapi belum delivered/invoiced tidak boleh masuk revenue; revenue transaksi baru baseline Rp0 | — | Not Run | — |
| T-35 | Normal | S00004 memiliki audit event seed actor, 01/10/2026 09.00 WIB, Confirmed + reservation10 | — | Not Run | — |
| T-36 | Edge | Post ulang invoice Posted hanya menghasilkan 1 invoice post, 1 journal, dan AR tidak dobel | — | Not Run | — |

## Evidence naming suggestion

`T-01_owner-sales-access.png`, `T-13_delivery-backorder.png`, `T-23_vendor-bill-grni.png`, dan seterusnya. Simpan screenshot dari aplikasi, response/API log bila relevan, serta query rekonsiliasi dalam folder evidence repository. Satu screenshot tidak cukup jika expected result memerlukan bukti dari dua modul.
