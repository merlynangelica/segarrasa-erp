# Role Assignment Sheet — Group ___

| Member | Name / Student ID | Functional Role | Primary Module (max 2) | F features owned | T tests owned | Demo segment |
|---|---|---|---|---|---|---|
| M1 | __________________ | Product Owner / PM / Business Analyst | Sales, CRM | __________ | __________ | __________ |
| M2 | __________________ | Lead AI Developer | Purchase, Inventory | __________ | __________ | __________ |
| M3 | __________________ | UI/UX and Frontend Lead | Quality, Sales co-owner | __________ | __________ | __________ |
| M4 | __________________ | QA and Deployment Lead | Accounting / Invoicing, Quality co-owner | __________ | __________ | __________ |

Each member must show end-to-end ownership of at least one module: requirement, build, test, and demo. Co-owner contributions must include real code changes and tests. Attach repository commit references and proof of individual contribution.
