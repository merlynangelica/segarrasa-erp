# Contribution Table — Group ___

| Member | Role | Module | F features changed/built | T tests executed | Evidence links | Key commits |
|---|---|---|---|---|---|---|
| M1 | __________ | __________ | __________ | __________ | __________ | __________ |
| M2 | __________ | __________ | __________ | __________ | __________ | __________ |
| M3 | __________ | __________ | __________ | __________ | __________ | __________ |
| M4 | __________ | __________ | __________ | __________ | __________ | __________ |

Use actual commit hashes and test evidence. Do not list a feature or test as an individual contribution unless that member performed and can explain the work.
