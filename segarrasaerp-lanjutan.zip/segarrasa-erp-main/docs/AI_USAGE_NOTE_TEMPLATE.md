# AI Tool Usage Note — Group ___

| Date | AI tool / model | Task / prompt summary | Files or code affected | Human review performed | Test / verification evidence |
|---|---|---|---|---|---|
| __________ | __________ | __________ | __________ | __________ | __________ |
| __________ | __________ | __________ | __________ | __________ | __________ |
| __________ | __________ | __________ | __________ | __________ | __________ |

Describe how generated code was reviewed, which business rules were checked against the handout, defects found in generated output, and how those defects were corrected and re-tested. AI assistance must be disclosed, not represented as independent implementation by a team member.
