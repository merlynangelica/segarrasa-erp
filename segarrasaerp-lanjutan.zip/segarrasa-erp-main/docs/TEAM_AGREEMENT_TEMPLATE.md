# Team Agreement — Group ___

## Working rhythm

- Regular meeting day/time: ______________________________
- Main communication channel: ____________________________
- Repository and branch policy: ___________________________
- Task board / issue tracker: _____________________________

## Approval and decision process

- Module owner: __________________________________________
- Reviewer / approver: ___________________________________
- How conflicting business rules are escalated: ___________
- How changes to confirmed workflows are reviewed: ________

## Delivery and quality controls

- Definition of a completed feature: code + review + test + evidence.
- Every feature change must be committed with a descriptive message.
- Re-run affected regression tests after each integration change.
- Baseline seed must be reset before each independent T-xx test unless a fixture explicitly says otherwise.
- Shared code, prompts, or solutions must not be exchanged with other groups.

## Delay / absence mitigation

- How work is reassigned: _________________________________
- How a blocked dependency is escalated: _________________
- How role changes are recorded in README: ________________

## Member acknowledgement

| Member | Name | Date | Agreement / initials |
|---|---|---|---|
| M1 | __________ | __________ | __________ |
| M2 | __________ | __________ | __________ |
| M3 | __________ | __________ | __________ |
| M4 | __________ | __________ | __________ |
