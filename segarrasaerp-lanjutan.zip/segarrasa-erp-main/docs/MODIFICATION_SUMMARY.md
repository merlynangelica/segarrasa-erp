# Catatan Perubahan — Lanjutan Project ERP SegarRasa

## Prinsip perubahan

Project kelompok dipertahankan pada struktur Flask + SQLite + HTML/CSS/Vanilla JavaScript yang sudah ada. Tidak dilakukan rebuild framework atau penggantian struktur folder. `app/static/app.js` tetap dipakai; workflow tambahan diletakkan pada `app/static/workflows.js`. Perubahan backend dilakukan pada file yang sudah ada agar proses transaksi dan validasi dapat terhubung.

## Area yang dilanjutkan

- **Database:** penambahan tabel/kolom/index secara additive untuk quotation, vendor bill lines, credit note, revisi SO, tax line, QC, dan idempotency. Tidak ada perintah DROP TABLE atau rebuild tabel lama.
- **Akses:** permission diperiksa pada API berdasarkan enam role. Navigasi frontend bukan satu-satunya pengaman.
- **Sales:** credit exposure, validasi Available, reservasi, partial delivery/backorder, invoice berdasarkan delivered qty, serta posting yang idempotent.
- **Purchase:** vendor pricelist, PO approval Owner untuk subtotal di atas Rp1.000.000, receipt, QC Pass/Fail, accepted quantity, GRNI, dan three-way match Vendor Bill.
- **Accounting:** tax simulasi efektif 11% per line, double-entry journal, partial payment, return/Credit Note, pembalikan COGS untuk barang saleable, dan trial balance.
- **Inventory:** dua lokasi, transfer, return-to-stock, stock valuation, dan audit event.
- **CRM / reporting:** Lead → Quotation → SO, related-document links, role-aware dashboard, dan Form detail untuk master/dokumen.
- **UI:** layer workflow tambahan dan List/Kanban/Form/Activity navigation; beberapa input masih menggunakan prompt dan ID database untuk menghindari rewrite besar terhadap frontend awal.
- **Dokumentasi:** README, traceability, architecture/data model, Decision Log, serta template test dan kontribusi kelompok.

## Pemeriksaan yang sudah dilakukan pada salinan kerja

- `python -m py_compile app/*.py run.py tests/test_erp_acceptance.py` — berhasil.
- `node --check app/static/app.js` — berhasil.
- `node --check app/static/workflows.js` — berhasil.
- SQLite fresh schema — berhasil dibuat (35 tabel).
- SQLite additive migration pada salinan database demo — berhasil; foreign-key check tidak melaporkan pelanggaran.

## Yang belum dapat dinyatakan selesai

- Server Flask dan regression test HTTP belum dijalankan di lingkungan pembuatan ZIP karena dependency Flask tidak tersedia dan tidak dapat dipasang dari jaringan pada sesi ini. Jalankan `pip install -r requirements.txt`, lalu `python -m unittest discover -s tests -v` pada komputer tim.
- Regression suite yang disertakan adalah subset otomatis untuk alur dan aturan berisiko tinggi, bukan seluruh T-01–T-36.
- Seluruh T-01–T-36 tetap harus dijalankan pada browser dengan baseline fixture yang benar, lalu isi `docs/TEST_RESULTS_TEMPLATE.md` dengan actual result, pass/fail, dan bukti screenshot.
- **SO revision masih parsial:** permintaan revisi tercatat dengan alasan/audit; perubahan nilai komersial penuh belum diimplementasikan.
- **Dashboard drill-through masih perlu verifikasi:** tautan dokumen tersedia pada detail, tetapi semua KPI perlu diuji langsung terhadap definisi dan dokumen sumbernya.
- Beberapa layar belum memiliki kedalaman Form View setara Odoo dan sebagian workflow masih meminta database ID/kuantitas melalui prompt.
- F-23 Lot/Expiry merupakan fitur optional dan tidak diimplementasikan.
- Dokumen Role Assignment, Team Agreement, Contribution Table, dan AI Usage Note disediakan sebagai template; kelompok harus mengisi nama, tanggal, kontribusi, keputusan, dan alat yang benar-benar dipakai.
- Tidak ada URL publik yang dibuat dari workspace ini. Deployment pada hosting dengan persistent disk dan uji akses eksternal tetap menjadi tugas kelompok.

## Sebelum pengumpulan

1. Instal dependency dan jalankan regression suite.
2. Jalankan dan dokumentasikan T-01 sampai T-36 satu per satu sesuai baseline dan skenario pada handout.
3. Uji semua enam akun role, termasuk percobaan membuka URL API yang tidak diizinkan.
4. Lengkapi seluruh template berdasarkan kontribusi dan keputusan nyata kelompok.
5. Deploy aplikasi pada hosting yang menyimpan database secara persisten; ganti `SECRET_KEY` dan jangan gunakan password demo untuk deployment publik.
6. Rekam video demo maksimal 10 menit serta siapkan presentasi dan tanya jawab sesuai handout.
