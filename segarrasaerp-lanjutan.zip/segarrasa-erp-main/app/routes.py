from flask import Blueprint, request, jsonify, session
from werkzeug.security import check_password_hash
from .db import get_db, next_number, audit
from .auth import require
import sqlite3, math, json
from decimal import Decimal, ROUND_HALF_UP
from .auth import allowed

bp = Blueprint("api", __name__, url_prefix="/api")
def ok(data=None, status=200): return jsonify({"ok":True} if data is None else data), status
def money(n): return int(Decimal(str(n)).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
def tax_of(net):
    setting=get_db().execute("SELECT value FROM settings WHERE key='tax_effective_rate'").fetchone()
    rate=Decimal(str(setting["value"])) if setting else Decimal("0.11")
    return money(Decimal(int(net))*rate)
def posted_statuses(): return ("Posted", "Partial", "Paid")
def begin_write(db):
    """Acquire SQLite's write reservation before validating and mutating business state."""
    if not db.in_transaction:
        db.execute("BEGIN IMMEDIATE")
def add_journal(source_type, source_id, lines, prefix="MISC"):
    db=get_db()
    existing=db.execute("SELECT id,number FROM journal_entries WHERE source_type=? AND source_id=? ORDER BY id LIMIT 1", (source_type,source_id)).fetchone()
    if existing: return existing["id"], existing["number"], True
    clean=[(str(a),int(dr),int(cr)) for a,dr,cr in lines if int(dr) or int(cr)]
    debit=sum(x[1] for x in clean); credit=sum(x[2] for x in clean)
    if debit != credit: raise ValueError(f"Jurnal tidak balance: debit {debit}, credit {credit}")
    number=next_number(prefix)
    db.execute("INSERT INTO journal_entries(number,source_type,source_id,status) VALUES(?,?,?,'Posted')",(number,source_type,source_id))
    jid=db.execute("SELECT last_insert_rowid() id").fetchone()["id"]
    db.executemany("INSERT INTO journal_lines(journal_id,account_code,debit,credit) VALUES(?,?,?,?)",[(jid,*x) for x in clean])
    return jid,number,False
def rowdicts(rows): return [dict(r) for r in rows]
def user(): return session.get("user",{}).get("username","system")

@bp.post("/login")
def login():
    d=request.get_json() or {}
    r=get_db().execute("SELECT * FROM users WHERE username=? AND active=1",(d.get("username",""),)).fetchone()
    if not r or not check_password_hash(r["password_hash"],d.get("password","")):
        return jsonify({"error":"Username atau password salah"}),401
    session["user_id"]=r["id"]; session["user"]={"username":r["username"],"name":r["full_name"],"role":r["role"]}
    audit(r["username"],"Login",None,r["role"]);get_db().commit()
    return ok({"user":session["user"]})
@bp.post("/logout")
def logout():
    if session.get("user"): audit(user(),"Logout");get_db().commit()
    session.clear(); return ok()

@bp.get("/dashboard")
@require("dashboard.view")
def dashboard():
    db=get_db();role=session.get("user",{}).get("role");username=user()
    onhand=db.execute("SELECT COALESCE(SUM(on_hand),0) n FROM stock").fetchone()["n"]
    reserved=db.execute("SELECT COALESCE(SUM(quantity),0) n FROM reservations WHERE active=1").fetchone()["n"]
    payload={"company":"PT Segar Rasa Riau","on_hand":onhand,"reserved":reserved,"available":onhand-reserved}
    # Stock valuation, AR/AP, and revenue are restricted to Finance and Owner.
    if role in ("Finance","Owner"):
        payload["stock_value"]=db.execute("SELECT COALESCE(SUM(s.on_hand*p.standard_cost),0) n FROM stock s JOIN products p ON p.sku=s.sku").fetchone()["n"]
        payload["ar"]=db.execute("SELECT COALESCE(SUM(opening_ar),0) n FROM customers").fetchone()["n"] + db.execute("""SELECT COALESCE(SUM(MAX(i.total-i.paid_amount-COALESCE(cn.credited,0),0)),0) n
          FROM invoices i LEFT JOIN (SELECT invoice_id,SUM(total) credited FROM credit_notes WHERE status='Posted' GROUP BY invoice_id) cn ON cn.invoice_id=i.id
          WHERE i.status IN ('Posted','Partial','Paid')""").fetchone()["n"]
        payload["ap"]=db.execute("SELECT COALESCE(SUM(opening_ap),0) n FROM vendors").fetchone()["n"] + db.execute("SELECT COALESCE(SUM(total-paid_amount),0) n FROM vendor_bills WHERE status IN ('Posted','Partial','Paid')").fetchone()["n"]
        payload["revenue"]=db.execute("SELECT COALESCE(SUM(net_amount),0) n FROM invoices WHERE status IN ('Posted','Partial','Paid')").fetchone()["n"] - db.execute("SELECT COALESCE(SUM(net_amount),0) n FROM credit_notes WHERE status='Posted'").fetchone()["n"]
        payload.update({
          "posted_invoices":db.execute("SELECT COUNT(*) n FROM invoices WHERE status IN ('Posted','Partial','Paid')").fetchone()["n"],
          "open_customer_invoices":db.execute("SELECT COUNT(*) n FROM invoices WHERE status IN ('Posted','Partial')").fetchone()["n"],
          "open_vendor_bills":db.execute("SELECT COUNT(*) n FROM vendor_bills WHERE status IN ('Posted','Partial')").fetchone()["n"]
        })
    if role in ("Sales","Owner","Finance"):
        payload["sales_orders"]=db.execute("SELECT COUNT(*) n FROM sales_orders").fetchone()["n"]
        payload["open_sales_orders"]=db.execute("SELECT COUNT(*) n FROM sales_orders WHERE status='Confirmed'").fetchone()["n"]
    if role in ("Procurement","Owner","Finance"):
        payload["purchase_orders"]=db.execute("SELECT COUNT(*) n FROM purchase_orders").fetchone()["n"]
        payload["open_purchase_orders"]=db.execute("SELECT COUNT(*) n FROM purchase_orders WHERE status IN ('RFQ','Pending Approval','Confirmed')").fetchone()["n"]
    if role in ("Sales","Owner"):
        payload["open_leads"]=db.execute("SELECT COUNT(*) n FROM leads WHERE stage IN ('New','Qualified')").fetchone()["n"]
    if role in ("Quality","Owner"):
        payload["pending_quality_checks"]=db.execute("SELECT COUNT(*) n FROM receipts WHERE status='Draft' AND id IN (SELECT receipt_id FROM receipt_lines WHERE quality_checked_at IS NULL)").fetchone()["n"]
    if role in ("Owner","Finance"):
        payload["recent_audit"]=rowdicts(db.execute("SELECT * FROM audit_logs ORDER BY id DESC LIMIT 8").fetchall())
    else:
        payload["recent_audit"]=rowdicts(db.execute("SELECT * FROM audit_logs WHERE actor=? ORDER BY id DESC LIMIT 8",(username,)).fetchall())
    return ok(payload)

@bp.get("/masters/<kind>")
def masters(kind):
    permissions={"customers":"contacts.view","vendors":"purchase.view","products":"products.view",
                 "warehouses":"inventory.view","users":"*"}
    if kind not in permissions:return jsonify({"error":"Unknown master"}),404
    if kind=="users" and session.get("user",{}).get("role")!="Owner":return jsonify({"error":"Owner only"}),403
    if kind!="users" and not allowed(permissions[kind]):return jsonify({"error":"Akses ditolak","required_permission":permissions[kind]}),403
    if kind=="users":rows=get_db().execute("SELECT id,username,full_name,role,active FROM users").fetchall()
    else:rows=get_db().execute(f"SELECT * FROM {kind}").fetchall()
    data=rowdicts(rows)
    if kind=="customers":
        # SR-09 / F-02: show AR + confirmed uninvoiced SO exposure without double counting.
        for customer in data:
            code=customer["code"]
            invoice_ar=get_db().execute("""SELECT COALESCE(SUM(MAX(i.total-i.paid_amount-COALESCE(cn.credited,0),0)),0) n
              FROM invoices i JOIN sales_orders so ON so.id=i.order_id
              LEFT JOIN (SELECT invoice_id,SUM(total) credited FROM credit_notes WHERE status='Posted' GROUP BY invoice_id) cn ON cn.invoice_id=i.id
              WHERE so.customer_code=? AND i.status IN ('Posted','Partial','Paid')""",(code,)).fetchone()["n"]
            uninvoiced=get_db().execute("""SELECT COALESCE(SUM(MAX(so.total-COALESCE(inv.invoiced,0),0)),0) n
              FROM sales_orders so LEFT JOIN (SELECT order_id,SUM(total) invoiced FROM invoices WHERE status IN ('Posted','Partial','Paid') GROUP BY order_id) inv ON inv.order_id=so.id
              WHERE so.customer_code=? AND so.status='Confirmed'""",(code,)).fetchone()["n"]
            customer["posted_invoice_residual"]=invoice_ar
            customer["confirmed_so_uninvoiced"]=uninvoiced
            customer["credit_exposure"]=int(customer.get("opening_ar") or 0)+invoice_ar+uninvoiced
            customer["credit_headroom"]=int(customer.get("credit_limit") or 0)-customer["credit_exposure"]
    return ok(data)

@bp.get("/masters/<kind>/<path:key>")
def master_detail(kind,key):
    db=get_db()
    mapping={"customers":("customers","code","contacts.view"),"vendors":("vendors","code","purchase.view"),"products":("products","sku","products.view")}
    if kind not in mapping:return jsonify({"error":"Unknown master type"}),404
    table,key_column,permission=mapping[kind]
    if not allowed(permission):return jsonify({"error":"Akses ditolak","required_permission":permission}),403
    row=db.execute(f"SELECT * FROM {table} WHERE {key_column}=?",(key,)).fetchone()
    if not row:return jsonify({"error":"Master data tidak ditemukan"}),404
    data=dict(row)
    if kind=="customers":
        invoice_ar=db.execute("""SELECT COALESCE(SUM(MAX(i.total-i.paid_amount-COALESCE(cn.credited,0),0)),0) n
          FROM invoices i JOIN sales_orders so ON so.id=i.order_id
          LEFT JOIN (SELECT invoice_id,SUM(total) credited FROM credit_notes WHERE status='Posted' GROUP BY invoice_id) cn ON cn.invoice_id=i.id
          WHERE so.customer_code=? AND i.status IN ('Posted','Partial','Paid')""",(key,)).fetchone()["n"]
        uninvoiced=db.execute("""SELECT COALESCE(SUM(MAX(so.total-COALESCE(inv.invoiced,0),0)),0) n
          FROM sales_orders so LEFT JOIN (SELECT order_id,SUM(total) invoiced FROM invoices WHERE status IN ('Posted','Partial','Paid') GROUP BY order_id) inv ON inv.order_id=so.id
          WHERE so.customer_code=? AND so.status='Confirmed'""",(key,)).fetchone()["n"]
        data["posted_invoice_residual"]=invoice_ar;data["confirmed_so_uninvoiced"]=uninvoiced
        data["credit_exposure"]=int(data.get("opening_ar") or 0)+invoice_ar+uninvoiced
        data["credit_headroom"]=int(data.get("credit_limit") or 0)-data["credit_exposure"]
    return ok(data)

@bp.get("/stock")
@require("inventory.view")
def stock():
    rows=get_db().execute("""SELECT s.sku,p.name,p.size,s.warehouse_code,w.name warehouse,
      s.on_hand,COALESCE((SELECT SUM(r.quantity) FROM reservations r WHERE r.sku=s.sku AND r.warehouse_code=s.warehouse_code AND r.active=1),0) reserved,
      s.on_hand-COALESCE((SELECT SUM(r.quantity) FROM reservations r WHERE r.sku=s.sku AND r.warehouse_code=s.warehouse_code AND r.active=1),0) available,
      p.standard_cost,s.on_hand*p.standard_cost stock_value
      FROM stock s JOIN products p ON p.sku=s.sku JOIN warehouses w ON w.code=s.warehouse_code ORDER BY s.sku,s.warehouse_code""").fetchall()
    return ok(rowdicts(rows))

@bp.get("/documents/<kind>")
def documents(kind):
    db=get_db()
    queries={
      "sales":("SELECT so.*,c.name customer FROM sales_orders so JOIN customers c ON c.code=so.customer_code ORDER BY so.id DESC","sales.view"),
      "purchase":("SELECT po.*,v.name vendor FROM purchase_orders po JOIN vendors v ON v.code=po.vendor_code ORDER BY po.id DESC","purchase.view"),
      "deliveries":("SELECT d.*,so.number sales_order FROM deliveries d JOIN sales_orders so ON so.id=d.order_id ORDER BY d.id DESC","delivery.view"),
      "receipts":("SELECT r.*,po.number purchase_order FROM receipts r JOIN purchase_orders po ON po.id=r.purchase_order_id ORDER BY r.id DESC","receipt.view"),
      "invoices":("SELECT i.*,so.number sales_order,c.name customer FROM invoices i JOIN sales_orders so ON so.id=i.order_id JOIN customers c ON c.code=so.customer_code ORDER BY i.id DESC","invoicing.view"),
      "bills":("SELECT b.*,po.number purchase_order FROM vendor_bills b JOIN purchase_orders po ON po.id=b.purchase_order_id ORDER BY b.id DESC","bills.view"),
      "transfers":("SELECT * FROM transfers ORDER BY id DESC","transfer.view"),
      "returns":("SELECT r.*,i.number invoice_number,cn.number credit_note_number FROM returns r JOIN invoices i ON i.id=r.invoice_id LEFT JOIN credit_notes cn ON cn.return_id=r.id ORDER BY r.id DESC","returns.view"),
      "credit-notes":("SELECT cn.*,r.number return_number,i.number invoice_number FROM credit_notes cn JOIN returns r ON r.id=cn.return_id JOIN invoices i ON i.id=cn.invoice_id ORDER BY cn.id DESC","returns.view"),
      "payments":("SELECT * FROM payments ORDER BY id DESC","payments.view"),
      "leads":("SELECT * FROM leads ORDER BY id DESC","crm.view"),
      "quotations":("SELECT q.*,l.number lead_number,c.name customer FROM quotations q LEFT JOIN leads l ON l.id=q.lead_id JOIN customers c ON c.code=q.customer_code ORDER BY q.id DESC","crm.view"),
      "journals":("SELECT * FROM journal_entries ORDER BY id DESC","accounting.view"),
      "audit":("SELECT * FROM audit_logs ORDER BY id DESC","accounting.view")
    }
    if kind not in queries:return jsonify({"error":"Unknown document type"}),404
    sql,permission=queries[kind]
    if not allowed(permission):return jsonify({"error":"Akses ditolak","required_permission":permission}),403
    return ok(rowdicts(db.execute(sql).fetchall()))

@bp.get("/documents/<kind>/<int:doc_id>")
def document_detail(kind,doc_id):
    db=get_db()
    mapping={"sales":("sales_orders","sales.view"),"purchase":("purchase_orders","purchase.view"),
             "deliveries":("deliveries","delivery.view"),"receipts":("receipts","receipt.view"),
             "invoices":("invoices","invoicing.view"),"bills":("vendor_bills","bills.view"),
             "transfers":("transfers","transfer.view"),"returns":("returns","returns.view"),
             "leads":("leads","crm.view"),"quotations":("quotations","crm.view"),
             "credit-notes":("credit_notes","returns.view"),"payments":("payments","payments.view"),
             "journals":("journal_entries","accounting.view"),"audit":("audit_logs","accounting.view")}
    if kind not in mapping:return jsonify({"error":"Unknown document type"}),404
    table,permission=mapping[kind]
    if not allowed(permission):return jsonify({"error":"Akses ditolak","required_permission":permission}),403
    header=db.execute(f"SELECT * FROM {table} WHERE id=?",(doc_id,)).fetchone()
    if not header:return jsonify({"error":"Dokumen tidak ditemukan"}),404
    header=dict(header); child_queries={
      "sales":("SELECT * FROM sales_order_lines WHERE order_id=?",doc_id),
      "purchase":("SELECT * FROM purchase_order_lines WHERE order_id=?",doc_id),
      "deliveries":("SELECT * FROM delivery_lines WHERE delivery_id=?",doc_id),
      "receipts":("SELECT * FROM receipt_lines WHERE receipt_id=?",doc_id),
      "invoices":("SELECT * FROM invoice_lines WHERE invoice_id=?",doc_id),
      "bills":("SELECT * FROM vendor_bill_lines WHERE bill_id=?",doc_id),
      "quotations":("SELECT * FROM quotation_lines WHERE quotation_id=?",doc_id),
      "journals":("SELECT * FROM journal_lines WHERE journal_id=?",doc_id)}
    if kind in child_queries:
        sql,args=child_queries[kind]; header["lines"]=rowdicts(db.execute(sql,(args,)).fetchall())
    if kind=="returns":header["credit_note"]=dict(db.execute("SELECT * FROM credit_notes WHERE return_id=?",(doc_id,)).fetchone() or {})

    # SR-15 / SR-18 / SR-19: related-document smart links for traceable drill-through.
    related=[]
    def add_related(doc_kind, doc_id, number, status, permission, relation):
        if doc_id is not None and allowed(permission):
            related.append({"kind":doc_kind,"id":doc_id,"number":number,"status":status,"relation":relation})
    if kind=="sales":
        for x in db.execute("SELECT id,number,status FROM deliveries WHERE order_id=? ORDER BY id",(doc_id,)).fetchall(): add_related("deliveries",x["id"],x["number"],x["status"],"delivery.view","Delivery")
        for x in db.execute("SELECT id,number,status FROM invoices WHERE order_id=? ORDER BY id",(doc_id,)).fetchall(): add_related("invoices",x["id"],x["number"],x["status"],"invoicing.view","Customer Invoice")
        for x in db.execute("SELECT id,sku,quantity,active FROM reservations WHERE document_no=? ORDER BY id",(header["number"],)).fetchall():
            related.append({"kind":"reservation","id":x["id"],"number":f"{x['sku']} × {x['quantity']}","status":"Active" if x["active"] else "Released","relation":"Stock Reservation"})
        if header.get("quotation_id"):
            q=db.execute("SELECT id,number,status FROM quotations WHERE id=?",(header["quotation_id"],)).fetchone()
            if q:add_related("quotations",q["id"],q["number"],q["status"],"crm.view","Source Quotation")
    elif kind=="purchase":
        for x in db.execute("SELECT id,number,status FROM receipts WHERE purchase_order_id=? ORDER BY id",(doc_id,)).fetchall(): add_related("receipts",x["id"],x["number"],x["status"],"receipt.view","Receipt")
        for x in db.execute("SELECT id,number,status FROM vendor_bills WHERE purchase_order_id=? ORDER BY id",(doc_id,)).fetchall(): add_related("bills",x["id"],x["number"],x["status"],"bills.view","Vendor Bill")
    elif kind=="deliveries":
        so=db.execute("SELECT id,number,status FROM sales_orders WHERE id=?",(header["order_id"],)).fetchone()
        if so:add_related("sales",so["id"],so["number"],so["status"],"sales.view","Source Sales Order")
    elif kind=="receipts":
        po=db.execute("SELECT id,number,status FROM purchase_orders WHERE id=?",(header["purchase_order_id"],)).fetchone()
        if po:add_related("purchase",po["id"],po["number"],po["status"],"purchase.view","Source Purchase Order")
        for x in db.execute("SELECT id,number,status FROM vendor_bills WHERE receipt_id=? ORDER BY id",(doc_id,)).fetchall(): add_related("bills",x["id"],x["number"],x["status"],"bills.view","Vendor Bill")
    elif kind=="invoices":
        so=db.execute("SELECT id,number,status FROM sales_orders WHERE id=?",(header["order_id"],)).fetchone()
        if so:add_related("sales",so["id"],so["number"],so["status"],"sales.view","Source Sales Order")
        for x in db.execute("SELECT id,number,status FROM returns WHERE invoice_id=? ORDER BY id",(doc_id,)).fetchall(): add_related("returns",x["id"],x["number"],x["status"],"returns.view","Return")
    elif kind=="bills":
        for x in db.execute("SELECT id,number,status FROM receipts WHERE id=?",(header["receipt_id"],)).fetchall(): add_related("receipts",x["id"],x["number"],x["status"],"receipt.view","Source Receipt")
        for x in db.execute("SELECT id,number,status FROM purchase_orders WHERE id=?",(header["purchase_order_id"],)).fetchall(): add_related("purchase",x["id"],x["number"],x["status"],"purchase.view","Source Purchase Order")
    elif kind=="returns":
        inv=db.execute("SELECT id,number,status FROM invoices WHERE id=?",(header["invoice_id"],)).fetchone()
        if inv:add_related("invoices",inv["id"],inv["number"],inv["status"],"invoicing.view","Source Customer Invoice")
        cn=db.execute("SELECT id,number,status FROM credit_notes WHERE return_id=?",(doc_id,)).fetchone()
        if cn:related.append({"kind":"credit-note","id":cn["id"],"number":cn["number"],"status":cn["status"],"relation":"Credit Note"})
    elif kind=="leads":
        for x in db.execute("SELECT id,number,status FROM quotations WHERE lead_id=? ORDER BY id",(doc_id,)).fetchall(): add_related("quotations",x["id"],x["number"],x["status"],"crm.view","Quotation")
    elif kind=="quotations":
        if header.get("converted_order_id"):
            so=db.execute("SELECT id,number,status FROM sales_orders WHERE id=?",(header["converted_order_id"],)).fetchone()
            if so:add_related("sales",so["id"],so["number"],so["status"],"sales.view","Converted Sales Order")
    elif kind=="payments":
        pay_kind="invoices" if header["document_type"]=="customer" else "vendor_bills"
        pay_doc=db.execute(f"SELECT id,number,status FROM {pay_kind} WHERE id=?",(header["document_id"],)).fetchone()
        if pay_doc:add_related("invoices" if pay_kind=="invoices" else "bills",pay_doc["id"],pay_doc["number"],pay_doc["status"],"invoicing.view" if pay_kind=="invoices" else "bills.view","Paid Document")
    elif kind=="credit-notes":
        ret=db.execute("SELECT id,number,status FROM returns WHERE id=?",(header["return_id"],)).fetchone()
        if ret:add_related("returns",ret["id"],ret["number"],ret["status"],"returns.view","Source Return")
        inv=db.execute("SELECT id,number,status FROM invoices WHERE id=?",(header["invoice_id"],)).fetchone()
        if inv:add_related("invoices",inv["id"],inv["number"],inv["status"],"invoicing.view","Credited Invoice")
    header["related_docs"]=related
    return ok(header)

@bp.post("/products")
@require("*")
def create_product_variant():
    # Owner-only master-data maintenance; SKU uniqueness is enforced by the database primary key.
    if session.get("user", {}).get("role") != "Owner":
        return jsonify({"error":"Hanya Owner yang dapat menambah product variant"}),403
    d=request.get_json(silent=True) or {};db=get_db();begin_write(db)
    sku=str(d.get("sku") or "").strip().upper();name=str(d.get("name") or "").strip()
    size=str(d.get("size") or "").strip();color=str(d.get("color") or "").strip();unit=str(d.get("unit") or "").strip()
    vendor=str(d.get("default_vendor") or "").strip().upper()
    try:sales_price=int(d.get("sales_price"));cost=int(d.get("standard_cost"))
    except (TypeError,ValueError):return jsonify({"error":"Harga jual dan standard cost harus berupa angka bulat"}),400
    if not all([sku,name,size,unit,vendor]) or sales_price<=0 or cost<0:return jsonify({"error":"SKU, nama, ukuran, unit, vendor, dan harga wajib valid"}),400
    if not db.execute("SELECT 1 FROM vendors WHERE code=?",(vendor,)).fetchone():return jsonify({"error":"Default vendor tidak ditemukan"}),400
    if db.execute("SELECT 1 FROM products WHERE sku=?",(sku,)).fetchone():return jsonify({"error":f"SKU {sku} sudah digunakan; variant SKU harus unik"}),409
    db.execute("INSERT INTO products(sku,name,size,color,unit,sales_price,standard_cost,default_vendor,active) VALUES(?,?,?,?,?,?,?, ?,1)",(sku,name,size,color,unit,sales_price,cost,vendor))
    db.execute("INSERT INTO vendor_pricelist(vendor_id,variant_sku,min_qty,purchase_price,currency) VALUES(?,?,1,?,'IDR')",(vendor,sku,cost))
    db.executemany("INSERT INTO stock(sku,warehouse_code,on_hand) VALUES(?,?,0)",[(sku,x["code"]) for x in db.execute("SELECT code FROM warehouses").fetchall()])
    audit(user(),"Create Product Variant",sku,f"{name} {size}; default vendor {vendor}");db.commit()
    return ok({"sku":sku,"name":name,"status":"Created"},201)


@bp.post("/sales-orders")
@require("sales.create")
def create_so():
    d=request.get_json() or {}; db=get_db();begin_write(db)
    lines=d.get("lines",[])
    if not lines:return jsonify({"error":"Tambahkan minimal satu product line"}),400
    if not db.execute("SELECT 1 FROM customers WHERE code=?",(d.get("customer_code"),)).fetchone():return jsonify({"error":"Customer tidak ditemukan"}),400
    discount=float(d.get("discount_pct",0))
    if discount<0 or discount>100:return jsonify({"error":"Discount tidak valid"}),400
    subtotal=0; prepared=[]
    seen_skus=set()
    for line in lines:
        if line.get("sku") in seen_skus:return jsonify({"error":"SKU yang sama cukup satu baris; gabungkan quantity agar reservasi tidak terduplikasi"}),400
        seen_skus.add(line.get("sku"))
        p=db.execute("SELECT * FROM products WHERE sku=?",(line.get("sku"),)).fetchone()
        qty=int(line.get("quantity",0))
        if not p or qty<=0:return jsonify({"error":"SKU/quantity tidak valid"}),400
        discount_factor=(Decimal("100")-Decimal(str(discount)))/Decimal("100")
        net=money(Decimal(qty*int(p["sales_price"]))*discount_factor); tax=tax_of(net)
        prepared.append((p["sku"],qty,p["sales_price"],discount,net,tax,net+tax));subtotal+=net
    tax=sum(x[5] for x in prepared); total=subtotal+tax
    no=next_number("S")
    cur=db.execute("INSERT INTO sales_orders(number,customer_code,status,discount_pct,subtotal,tax,total,warehouse_code,created_by) VALUES(?,?,'Draft',?,?,?,?,?,?)",
        (no,d["customer_code"],discount,subtotal,tax,total,d.get("warehouse_code","WH-PKU"),user()))
    oid=cur.lastrowid
    for sku,qty,price,disc,net,tx,gross in prepared:
        db.execute("INSERT INTO sales_order_lines(order_id,sku,quantity,unit_price,discount_pct,subtotal,tax,total) VALUES(?,?,?,?,?,?,?,?)",(oid,sku,qty,price,disc,net,tx,gross))
    audit(user(),"Create Sales Order",no,f"Total {total}")
    db.commit();return ok({"id":oid,"number":no,"total":total},201)

@bp.post("/sales-orders/<int:oid>/confirm")
@require("sales.confirm")
def confirm_so(oid):
    db=get_db();begin_write(db);so=db.execute("SELECT * FROM sales_orders WHERE id=?",(oid,)).fetchone()
    if not so:return jsonify({"error":"SO tidak ditemukan"}),404
    if so["status"]!="Draft":return jsonify({"error":"SO bukan Draft; dokumen Confirmed terkunci"}),409
    if so["discount_pct"]>10 and session["user"]["role"]!="Owner":return jsonify({"error":"Diskon di atas 10% memerlukan approval Owner"}),409
    ar=db.execute("SELECT COALESCE(SUM(opening_ar),0) n FROM customers WHERE code=?",(so["customer_code"],)).fetchone()["n"]
    ar+=db.execute("""SELECT COALESCE(SUM(MAX(i.total-i.paid_amount-COALESCE(cn.credited,0),0)),0) n
      FROM invoices i JOIN sales_orders s ON s.id=i.order_id
      LEFT JOIN (SELECT invoice_id,SUM(total) credited FROM credit_notes WHERE status='Posted' GROUP BY invoice_id) cn ON cn.invoice_id=i.id
      WHERE s.customer_code=? AND i.status IN ('Posted','Partial','Paid')""",(so["customer_code"],)).fetchone()["n"]
    uninvoiced=db.execute("""SELECT COALESCE(SUM(MAX(so.total-COALESCE(inv.invoiced,0),0)),0) n FROM sales_orders so
      LEFT JOIN (SELECT order_id,SUM(total) invoiced FROM invoices WHERE status IN ('Posted','Partial','Paid') GROUP BY order_id) inv ON inv.order_id=so.id
      WHERE so.customer_code=? AND so.status='Confirmed'""",(so["customer_code"],)).fetchone()["n"]
    customer=db.execute("SELECT credit_limit FROM customers WHERE code=?",(so["customer_code"],)).fetchone()
    exposure=ar+uninvoiced+so["total"]
    if exposure>customer["credit_limit"]:return jsonify({"error":f"Credit limit terlampaui. Exposure {exposure:,}; limit {customer['credit_limit']:,}"}),409
    lines=db.execute("SELECT * FROM sales_order_lines WHERE order_id=?",(oid,)).fetchall()
    for line in lines:
        reserved=db.execute("SELECT COALESCE(SUM(quantity),0) n FROM reservations WHERE sku=? AND warehouse_code=? AND active=1",(line["sku"],so["warehouse_code"])).fetchone()["n"]
        stockrow=db.execute("SELECT on_hand FROM stock WHERE sku=? AND warehouse_code=?",(line["sku"],so["warehouse_code"])).fetchone()
        available=(stockrow["on_hand"] if stockrow else 0)-reserved
        if line["quantity"]>available:return jsonify({"error":f"Available stock {available} tidak cukup untuk {line['sku']}"}),409
    for line in lines:
        db.execute("INSERT INTO reservations(document_no,sku,warehouse_code,quantity,active) VALUES(?,?,?,?,1)",(so["number"],line["sku"],so["warehouse_code"],line["quantity"]))
    db.execute("UPDATE sales_orders SET status='Confirmed',confirmed_at=CURRENT_TIMESTAMP WHERE id=?",(oid,))
    audit(user(),"Confirm + reserve",so["number"],f"Stock reservation created; credit exposure {exposure}; discount approval: {'Owner' if so['discount_pct']>10 else 'Not required'}");db.commit()
    return ok({"status":"Confirmed","number":so["number"],"credit_exposure":exposure})

@bp.post("/sales-orders/<int:oid>/delivery")
@require("delivery.create")
def create_delivery(oid):
    d=request.get_json() or {}; db=get_db();begin_write(db)
    so=db.execute("SELECT * FROM sales_orders WHERE id=?",(oid,)).fetchone()
    if not so or so["status"]!="Confirmed":return jsonify({"error":"SO harus Confirmed"}),409
    qtymap=d.get("quantities",{})
    lines=db.execute("SELECT * FROM sales_order_lines WHERE order_id=?",(oid,)).fetchall()
    if not any(int(qtymap.get(line["sku"],0))>0 for line in lines):return jsonify({"error":"Delivery harus memiliki minimal satu quantity positif"}),400
    no=next_number("DO"); cur=db.execute("INSERT INTO deliveries(number,order_id,warehouse_code) VALUES(?,?,?)",(no,oid,so["warehouse_code"]))
    did=cur.lastrowid
    for line in lines:
        qty=int(qtymap.get(line["sku"],0))
        delivered=db.execute("SELECT COALESCE(SUM(dl.quantity),0) n FROM delivery_lines dl JOIN deliveries d ON d.id=dl.delivery_id WHERE d.order_id=? AND d.status='Done' AND dl.sku=?",(oid,line["sku"])).fetchone()["n"]
        own_reserved=db.execute("SELECT COALESCE(SUM(quantity),0) n FROM reservations WHERE document_no=? AND sku=? AND warehouse_code=? AND active=1",(so["number"],line["sku"],so["warehouse_code"])).fetchone()["n"]
        if qty<0 or qty+delivered>line["quantity"] or qty>own_reserved:return jsonify({"error":"Delivery melebihi ordered quantity atau reservasi aktif"}),409
        if qty:
            db.execute("INSERT INTO delivery_lines(delivery_id,sku,quantity) VALUES(?,?,?)",(did,line["sku"],qty))
    audit(user(),"Create Delivery",no,so["number"]);db.commit();return ok({"id":did,"number":no},201)

@bp.post("/deliveries/<int:did>/validate")
@require("delivery.validate")
def validate_delivery(did):
    db=get_db();begin_write(db);d=db.execute("SELECT * FROM deliveries WHERE id=?",(did,)).fetchone()
    if not d:return jsonify({"error":"Delivery tidak ditemukan"}),404
    if d["status"]=="Done":return ok({"status":"Done","idempotent":True})
    if d["status"]!="Ready":return jsonify({"error":"Delivery bukan Ready"}),409
    lines=db.execute("SELECT * FROM delivery_lines WHERE delivery_id=?",(did,)).fetchall()
    if not lines:return jsonify({"error":"Delivery kosong"}),400
    cogs=0
    for l in lines:
        stockrow=db.execute("SELECT on_hand FROM stock WHERE sku=? AND warehouse_code=?",(l["sku"],d["warehouse_code"])).fetchone()
        own=db.execute("SELECT COALESCE(SUM(quantity),0) n FROM reservations WHERE document_no=(SELECT number FROM sales_orders WHERE id=?) AND sku=? AND warehouse_code=? AND active=1",(d["order_id"],l["sku"],d["warehouse_code"])).fetchone()["n"]
        if not stockrow or l["quantity"]>stockrow["on_hand"] or l["quantity"]>own:return jsonify({"error":"On Hand/reservasi order tidak cukup"}),409
    for l in lines:
        db.execute("UPDATE stock SET on_hand=on_hand-? WHERE sku=? AND warehouse_code=?",(l["quantity"],l["sku"],d["warehouse_code"]))
        db.execute("UPDATE reservations SET quantity=quantity-? WHERE document_no=(SELECT number FROM sales_orders WHERE id=?) AND sku=? AND warehouse_code=? AND active=1",(l["quantity"],d["order_id"],l["sku"],d["warehouse_code"]))
        db.execute("UPDATE reservations SET active=0 WHERE document_no=(SELECT number FROM sales_orders WHERE id=?) AND quantity<=0",(d["order_id"],))
        cost=db.execute("SELECT standard_cost FROM products WHERE sku=?",(l["sku"],)).fetchone()["standard_cost"]
        cogs+=cost*l["quantity"]
    if cogs:add_journal("Delivery",did,[("5100",cogs,0),("1200",0,cogs)])
    db.execute("UPDATE deliveries SET status='Done',validated_at=CURRENT_TIMESTAMP WHERE id=?",(did,))
    audit(user(),"Validate Delivery",d["number"],f"Stock decrease + COGS {cogs}");db.commit()
    return ok({"status":"Done","cogs":cogs})

@bp.post("/invoices/from-order/<int:oid>")
@require("invoicing.post")
def invoice_from_order(oid):
    db=get_db();begin_write(db);so=db.execute("SELECT * FROM sales_orders WHERE id=?",(oid,)).fetchone()
    if not so or so["status"]!="Confirmed":return jsonify({"error":"SO belum Confirmed"}),409
    lines=db.execute("SELECT * FROM sales_order_lines WHERE order_id=?",(oid,)).fetchall()
    invoice_lines=[];net=0;tax=0
    for l in lines:
        delivered=db.execute("SELECT COALESCE(SUM(dl.quantity),0) n FROM delivery_lines dl JOIN deliveries d ON d.id=dl.delivery_id WHERE d.order_id=? AND d.status='Done' AND dl.sku=?",(oid,l["sku"])).fetchone()["n"]
        already=db.execute("SELECT COALESCE(SUM(il.quantity),0) n FROM invoice_lines il JOIN invoices i ON i.id=il.invoice_id WHERE i.order_id=? AND i.status!='Cancelled' AND il.sku=?",(oid,l["sku"])).fetchone()["n"]
        qty=delivered-already
        if qty>0:
            discount_factor=(Decimal("100")-Decimal(str(l["discount_pct"])))/Decimal("100")
            n=money(Decimal(qty*l["unit_price"])*discount_factor);t=tax_of(n)
            invoice_lines.append((l["sku"],qty,l["unit_price"],n,t));net+=n;tax+=t
    if not invoice_lines:return jsonify({"error":"Belum ada delivered quantity yang dapat ditagih"}),409
    no=next_number("INV");cur=db.execute("INSERT INTO invoices(number,order_id,status,net_amount,tax_amount,total) VALUES(?,?,'Draft',?,?,?)",(no,oid,net,tax,net+tax))
    iid=cur.lastrowid
    for x in invoice_lines:db.execute("INSERT INTO invoice_lines(invoice_id,sku,quantity,unit_price,net_amount,tax_amount) VALUES(?,?,?,?,?,?)",(iid,*x))
    audit(user(),"Create Customer Invoice",no,so["number"]);db.commit();return ok({"id":iid,"number":no,"net":net,"tax":tax,"total":net+tax},201)

@bp.post("/invoices/<int:iid>/post")
@require("invoicing.post")
def post_invoice(iid):
    db=get_db();begin_write(db);inv=db.execute("SELECT * FROM invoices WHERE id=?",(iid,)).fetchone()
    if not inv:return jsonify({"error":"Invoice tidak ditemukan"}),404
    if inv["status"] in ("Posted","Partial","Paid"):return ok({"status":inv["status"],"idempotent":True})
    if inv["status"]!="Draft":return jsonify({"error":"Invalid status"}),409
    db.execute("UPDATE invoices SET status='Posted' WHERE id=?",(iid,))
    gross_before_discount=db.execute("SELECT COALESCE(SUM(quantity*unit_price),0) n FROM invoice_lines WHERE invoice_id=?",(iid,)).fetchone()["n"]
    discount_amount=gross_before_discount-inv["net_amount"]
    journal_lines=[("1100",inv["total"],0)]
    if discount_amount:journal_lines.append(("4110",discount_amount,0))
    journal_lines.extend([("4100",0,gross_before_discount),("2200",0,inv["tax_amount"])])
    add_journal("Customer Invoice",iid,journal_lines)
    audit(user(),"Post Customer Invoice",inv["number"],f"AR + gross revenue + discount contra-revenue + VAT Output; discount {discount_amount}");db.commit();return ok({"status":"Posted","discount_amount":discount_amount})

@bp.post("/purchase-orders")
@require("purchase.create")
def create_po():
    d=request.get_json() or {};db=get_db();begin_write(db);lines=d.get("lines",[])
    if not lines:return jsonify({"error":"Tambahkan product line"}),400
    if not db.execute("SELECT 1 FROM vendors WHERE code=?",(d.get("vendor_code"),)).fetchone():return jsonify({"error":"Vendor tidak ditemukan"}),400
    prepared=[];subtotal=0;tax=0;seen_skus=set()
    for x in lines:
        if x.get("sku") in seen_skus:return jsonify({"error":"SKU duplikat pada PO; gabungkan quantity"}),400
        seen_skus.add(x.get("sku"))
        p=db.execute("SELECT * FROM products WHERE sku=?",(x.get("sku"),)).fetchone();qty=int(x.get("quantity",0))
        if not p or qty<=0:return jsonify({"error":"SKU/quantity tidak valid"}),400
        price=db.execute("SELECT min_qty,purchase_price FROM vendor_pricelist WHERE vendor_id=? AND variant_sku=?",(d["vendor_code"],p["sku"])).fetchone()
        if not price:return jsonify({"error":f"{p['sku']} tidak tersedia pada pricelist vendor {d['vendor_code']}"}),409
        if qty<price["min_qty"]:return jsonify({"error":f"Minimum order {p['sku']} adalah {price['min_qty']} unit"}),409
        cost=int(price["purchase_price"])
        n=qty*cost;line_tax=tax_of(n);subtotal+=n;tax+=line_tax;prepared.append((p["sku"],qty,cost,n,line_tax))
    no=next_number("PO")
    cur=db.execute("INSERT INTO purchase_orders(number,vendor_code,status,subtotal,tax,total,created_by) VALUES(?,?,'RFQ',?,?,?,?)",(no,d["vendor_code"],subtotal,tax,subtotal+tax,user()))
    oid=cur.lastrowid
    for x in prepared:db.execute("INSERT INTO purchase_order_lines(order_id,sku,quantity,unit_cost,subtotal,tax) VALUES(?,?,?,?,?,?)",(oid,*x))
    audit(user(),"Create RFQ",no);db.commit();return ok({"id":oid,"number":no,"subtotal":subtotal,"total":subtotal+tax},201)

@bp.post("/purchase-orders/<int:oid>/confirm")
@require("purchase.confirm")
def confirm_po(oid):
    db=get_db();begin_write(db);po=db.execute("SELECT * FROM purchase_orders WHERE id=?",(oid,)).fetchone()
    if not po:return jsonify({"error":"PO tidak ditemukan"}),404
    if po["status"] not in ("RFQ","Pending Approval"):return jsonify({"error":"PO bukan RFQ"}),409
    threshold=int(db.execute("SELECT value FROM settings WHERE key='large_po_threshold'").fetchone()["value"])
    if po["subtotal"]>threshold:
        db.execute("UPDATE purchase_orders SET status='Pending Approval' WHERE id=?",(oid,))
        audit(user(),"Request PO Approval",po["number"],f"Subtotal {po['subtotal']} exceeds approval threshold {threshold}");db.commit()
        return ok({"status":"Pending Approval","message":"Menunggu tindakan approval eksplisit dari Owner"})
    db.execute("UPDATE purchase_orders SET status='Confirmed' WHERE id=?",(oid,))
    audit(user(),"Confirm Purchase Order",po["number"]);db.commit();return ok({"status":"Confirmed"})

@bp.post("/purchase-orders/<int:oid>/approve")
@require("purchase.confirm")
def approve_po(oid):
    if session["user"]["role"]!="Owner":return jsonify({"error":"Hanya Owner"}),403
    db=get_db();begin_write(db);po=db.execute("SELECT * FROM purchase_orders WHERE id=?",(oid,)).fetchone()
    if not po or po["status"]!="Pending Approval":return jsonify({"error":"PO tidak menunggu approval"}),409
    db.execute("UPDATE purchase_orders SET status='Confirmed' WHERE id=?",(oid,))
    audit(user(),"Approve Purchase Order",po["number"]);db.commit();return ok({"status":"Confirmed"})

@bp.post("/purchase-orders/<int:oid>/receipt")
@require("receipt.create")
def create_receipt(oid):
    d=request.get_json() or {};db=get_db();begin_write(db);po=db.execute("SELECT * FROM purchase_orders WHERE id=?",(oid,)).fetchone()
    if not po or po["status"]!="Confirmed":return jsonify({"error":"PO harus Confirmed"}),409
    lines=d.get("lines",[])
    if not lines:return jsonify({"error":"Receipt minimal memiliki satu baris"}),400
    seen=set();prepared=[]
    for x in lines:
        sku=x.get("sku");pol=db.execute("SELECT * FROM purchase_order_lines WHERE order_id=? AND sku=?",(oid,sku)).fetchone()
        if not pol or sku in seen:return jsonify({"error":"SKU tidak ada di PO atau duplikat"}),400
        seen.add(sku)
        try:qty=int(x.get("received_qty",0))
        except (TypeError,ValueError):return jsonify({"error":"Received quantity harus integer"}),400
        already=db.execute("SELECT COALESCE(SUM(received_qty),0) n FROM receipt_lines rl JOIN receipts r ON r.id=rl.receipt_id WHERE r.purchase_order_id=? AND rl.sku=? AND r.status!='Cancelled'",(oid,sku)).fetchone()["n"]
        if qty<=0 or already+qty>pol["quantity"]:return jsonify({"error":f"Receipt {sku} melebihi sisa PO"}),409
        prepared.append((sku,qty))
    warehouse=d.get("warehouse_code","WH-PKU")
    if not db.execute("SELECT 1 FROM warehouses WHERE code=?",(warehouse,)).fetchone():return jsonify({"error":"Warehouse tidak ditemukan"}),400
    no=next_number("WHIN");cur=db.execute("INSERT INTO receipts(number,purchase_order_id,warehouse_code,created_by) VALUES(?,?,?,?)",(no,oid,warehouse,user()))
    rid=cur.lastrowid
    for sku,qty in prepared:
        db.execute("INSERT INTO receipt_lines(receipt_id,sku,received_qty,accepted_qty,rejected_qty) VALUES(?,?,?,0,0)",(rid,sku,qty))
    audit(user(),"Create Receipt",no,po["number"]);db.commit();return ok({"id":rid,"number":no,"status":"Waiting Quality"},201)

@bp.post("/receipts/<int:rid>/quality-check")
@require("quality.check")
def quality_check_receipt(rid):
    d=request.get_json() or {};db=get_db();begin_write(db);r=db.execute("SELECT * FROM receipts WHERE id=?",(rid,)).fetchone()
    if not r or r["status"]!="Draft":return jsonify({"error":"Receipt bukan Draft"}),409
    try:accepted=int(d.get("accepted_qty",-1));rejected=int(d.get("rejected_qty",-1))
    except (TypeError,ValueError):return jsonify({"error":"Pass/Fail harus integer"}),400
    sku=str(d.get("sku") or "").strip();line=db.execute("SELECT * FROM receipt_lines WHERE receipt_id=? AND sku=?",(rid,sku)).fetchone()
    if not line:return jsonify({"error":"SKU tidak ada pada Receipt"}),404
    if line["quality_checked_at"] is not None:return jsonify({"error":"Quality Check sudah tercatat; buat audit koreksi melalui prosedur terkontrol"}),409
    if accepted<0 or rejected<0 or accepted+rejected!=line["received_qty"]:return jsonify({"error":"Pass + Fail harus sama dengan inspected quantity"}),400
    if rejected>0 and not str(d.get("quality_reason") or "").strip():return jsonify({"error":"Alasan Fail wajib dicatat"}),400
    db.execute("UPDATE receipt_lines SET accepted_qty=?,rejected_qty=?,quality_reason=?,quality_checked_by=?,quality_checked_at=CURRENT_TIMESTAMP WHERE id=?",(accepted,rejected,d.get("quality_reason"),user(),line["id"]))
    audit(user(),"Quality Check Pass/Fail",r["number"],f"{sku}: Pass {accepted}; Fail {rejected}; {d.get('quality_reason','')}")
    db.commit();return ok({"sku":sku,"accepted_qty":accepted,"rejected_qty":rejected})

@bp.post("/receipts/<int:rid>/validate")
@require("receipt.validate")
def validate_receipt(rid):
    db=get_db();begin_write(db);r=db.execute("SELECT * FROM receipts WHERE id=?",(rid,)).fetchone()
    if not r:return jsonify({"error":"Receipt tidak ditemukan"}),404
    if r["status"]=="Done":return ok({"status":"Done","idempotent":True})
    if r["status"]!="Draft":return jsonify({"error":"Receipt bukan Draft"}),409
    lines=db.execute("SELECT rl.*,p.standard_cost FROM receipt_lines rl JOIN products p ON p.sku=rl.sku WHERE rl.receipt_id=?",(rid,)).fetchall()
    if not lines:return jsonify({"error":"Receipt tidak memiliki baris"}),400
    if any(l["quality_checked_at"] is None or l["accepted_qty"]+l["rejected_qty"]!=l["received_qty"] for l in lines):return jsonify({"error":"Semua baris wajib melalui Quality Check Pass/Fail"}),409
    received_value=0
    for l in lines:
        if l["accepted_qty"]:
            db.execute("INSERT INTO stock(sku,warehouse_code,on_hand) VALUES(?,?,?) ON CONFLICT(sku,warehouse_code) DO UPDATE SET on_hand=on_hand+excluded.on_hand",(l["sku"],r["warehouse_code"],l["accepted_qty"]))
            received_value+=l["accepted_qty"]*l["standard_cost"]
        if l["rejected_qty"]:audit(user(),"Quality Fail",r["number"],f"{l['sku']} rejected {l['rejected_qty']}: {l['quality_reason']}")
    if received_value:add_journal("Receipt",rid,[("1200",received_value,0),("1210",0,received_value)])
    db.execute("UPDATE receipts SET status='Done' WHERE id=?",(rid,))
    audit(user(),"Validate Receipt",r["number"],f"Accepted value {received_value}; rejected excluded from stock and valuation");db.commit()
    return ok({"status":"Done","accepted_value":received_value})

@bp.post("/vendor-bills/from-receipt/<int:rid>")
@require("bills.post")
def bill_from_receipt(rid):
    db=get_db();begin_write(db);r=db.execute("SELECT * FROM receipts WHERE id=?",(rid,)).fetchone()
    if not r or r["status"]!="Done":return jsonify({"error":"Receipt belum tervalidasi"}),409
    existing=db.execute("SELECT id,number,match_status,match_details FROM vendor_bills WHERE receipt_id=?",(rid,)).fetchone()
    if existing:return ok({"id":existing["id"],"number":existing["number"],"match_status":existing["match_status"],"match_details":existing["match_details"],"idempotent":True})
    po=db.execute("SELECT * FROM purchase_orders WHERE id=?",(r["purchase_order_id"],)).fetchone()
    lines=db.execute("SELECT rl.*,pol.quantity po_qty,pol.unit_cost FROM receipt_lines rl JOIN purchase_order_lines pol ON pol.order_id=? AND pol.sku=rl.sku WHERE rl.receipt_id=?",(po["id"],rid)).fetchall()
    if not lines or not any(l["accepted_qty"] for l in lines):return jsonify({"error":"Tidak ada accepted quantity yang dapat ditagih"}),409
    payload=request.get_json(silent=True) or {}
    requested={}
    for item in payload.get("lines",[]) if isinstance(payload,dict) else []:
        sku=str(item.get("sku") or "").strip()
        try:qty=int(item.get("quantity",0))
        except (TypeError,ValueError):return jsonify({"error":"Vendor Bill quantity harus integer"}),400
        if not sku or qty<=0 or sku in requested:return jsonify({"error":"Bill line SKU/quantity tidak valid atau duplikat"}),400
        requested[sku]=qty
    net=0;tax=0;prepared=[];mismatches=[]
    for l in lines:
        qty=requested.pop(l["sku"],l["accepted_qty"])
        if qty<=0:continue
        if qty>l["received_qty"] or qty>l["po_qty"]:
            return jsonify({"error":f"Bill quantity {qty} {l['sku']} melebihi Receipt/PO quantity"}),409
        if qty>l["accepted_qty"]:
            mismatches.append(f"{l['sku']}: Vendor Bill {qty}, accepted {l['accepted_qty']} (selisih {qty-l['accepted_qty']})")
        line_net=qty*l["unit_cost"];line_tax=tax_of(line_net);net+=line_net;tax+=line_tax
        prepared.append((l["sku"],qty,l["unit_cost"],line_net,line_tax))
    if requested:return jsonify({"error":"SKU Vendor Bill tidak terdapat pada Receipt"}),400
    if not prepared:return jsonify({"error":"Vendor Bill tidak memiliki baris"}),409
    match_status="Mismatch" if mismatches else "Matched"
    match_details="; ".join(mismatches) if mismatches else "PO, Receipt, dan accepted quantity cocok"
    no=next_number("BILL");cur=db.execute("INSERT INTO vendor_bills(number,purchase_order_id,receipt_id,status,net_amount,tax_amount,total,match_status,match_details) VALUES(?,?,?,'Draft',?,?,?,?,?)",(no,po["id"],rid,net,tax,net+tax,match_status,match_details))
    bid=cur.lastrowid
    for row in prepared:db.execute("INSERT INTO vendor_bill_lines(bill_id,sku,quantity,unit_cost,net_amount,tax_amount) VALUES(?,?,?,?,?,?)",(bid,*row))
    audit(user(),"Create Vendor Bill",no,f"Three-way match {match_status}: {match_details}");db.commit()
    return ok({"id":bid,"number":no,"net":net,"tax":tax,"total":net+tax,"match_status":match_status,"match_details":match_details},201)

@bp.post("/vendor-bills/<int:bid>/post")
@require("bills.post")
def post_bill(bid):
    db=get_db();begin_write(db);b=db.execute("SELECT * FROM vendor_bills WHERE id=?",(bid,)).fetchone()
    if not b:return jsonify({"error":"Bill tidak ditemukan"}),404
    if b["status"] in ("Posted","Partial","Paid"):return ok({"status":b["status"],"idempotent":True})
    if b["status"]!="Draft":return jsonify({"error":"Bill bukan Draft"}),409
    # Re-check three-way match at posting, not only when the bill is created.
    r=db.execute("SELECT status FROM receipts WHERE id=?",(b["receipt_id"],)).fetchone()
    if not r or r["status"]!="Done":return jsonify({"error":"Receipt harus Done"}),409
    lines=db.execute("SELECT * FROM vendor_bill_lines WHERE bill_id=?",(bid,)).fetchall()
    if not lines:return jsonify({"error":"Vendor Bill tidak memiliki line"}),409
    differences=[]
    for line in lines:
        match=db.execute("SELECT accepted_qty FROM receipt_lines WHERE receipt_id=? AND sku=?",(b["receipt_id"],line["sku"])).fetchone()
        po_line=db.execute("SELECT unit_cost,quantity FROM purchase_order_lines WHERE order_id=? AND sku=?",(b["purchase_order_id"],line["sku"])).fetchone()
        if not match or not po_line or line["quantity"]>match["accepted_qty"] or line["quantity"]>po_line["quantity"] or line["unit_cost"]!=po_line["unit_cost"]:
            accepted=match["accepted_qty"] if match else 0
            differences.append(f"{line['sku']}: billed {line['quantity']}, accepted {accepted}")
    if differences:
        detail="; ".join(differences)
        db.execute("UPDATE vendor_bills SET match_status='Mismatch',match_details=? WHERE id=?",(detail,bid))
        audit(user(),"Vendor Bill Match Failed",b["number"],detail);db.commit()
        return jsonify({"error":"Three-way match gagal: " + detail,"match_status":"Mismatch"}),409
    db.execute("UPDATE vendor_bills SET status='Posted',match_status='Matched',match_details='PO, Receipt, dan accepted quantity cocok' WHERE id=?",(bid,))
    # GRNI is cleared; the VAT input is recognized at Vendor Bill posting.
    add_journal("Vendor Bill",bid,[("1210",b["net_amount"],0),("1300",b["tax_amount"],0),("2100",0,b["total"])])
    audit(user(),"Post Vendor Bill",b["number"],"Three-way match accepted qty; clear GRNI + VAT Input + AP");db.commit()
    return ok({"status":"Posted"})

@bp.post("/payments")
@require("payments.create")
def payment():
    d=request.get_json(silent=True) or {};db=get_db();begin_write(db);typ=d.get("document_type")
    try:docid=int(d.get("document_id",0));amount=int(d.get("amount",0))
    except (TypeError,ValueError):return jsonify({"error":"Document ID dan Payment amount harus angka bulat"}),400
    key=str(request.headers.get("Idempotency-Key") or d.get("idempotency_key") or "").strip() or None
    if key:
        previous=db.execute("SELECT p.number,p.amount,p.document_type,p.document_id,d.total-d.paid_amount residual,d.status FROM payments p JOIN (SELECT 'customer' typ,id,total,paid_amount,status FROM invoices UNION ALL SELECT 'vendor' typ,id,total,paid_amount,status FROM vendor_bills) d ON d.typ=p.document_type AND d.id=p.document_id WHERE p.idempotency_key=?",(key,)).fetchone()
        if previous:
            if (previous["document_type"],previous["document_id"],previous["amount"])!=(typ,docid,amount):
                return jsonify({"error":"Idempotency-Key sudah digunakan untuk payload pembayaran yang berbeda"}),409
            return ok({"number":previous["number"],"amount":previous["amount"],"residual":previous["residual"],"status":previous["status"],"idempotent":True})
    table="invoices" if typ=="customer" else "vendor_bills" if typ=="vendor" else None
    if not table or amount<=0:return jsonify({"error":"Payment harus positif dan jenis dokumen customer/vendor"}),400
    doc=db.execute(f"SELECT * FROM {table} WHERE id=? AND status IN ('Posted','Partial')",(docid,)).fetchone()
    if not doc:return jsonify({"error":"Dokumen harus Posted/Partial dan belum lunas"}),409
    residual=doc["total"]-doc["paid_amount"]
    if residual<=0 or amount>residual:return jsonify({"error":f"Payment melebihi residual {residual}"}),409
    no=next_number("PAY");cur=db.execute("INSERT INTO payments(number,document_type,document_id,amount,created_by,idempotency_key) VALUES(?,?,?,?,?,?)",(no,typ,docid,amount,user(),key))
    payment_id=cur.lastrowid;new_paid=doc["paid_amount"]+amount;new_status="Paid" if new_paid==doc["total"] else "Partial"
    db.execute(f"UPDATE {table} SET paid_amount=?,status=? WHERE id=?",(new_paid,new_status,docid))
    if typ=="customer":entries=[("1010",amount,0),("1100",0,amount)]
    else:entries=[("2100",amount,0),("1010",0,amount)]
    add_journal("Payment",payment_id,entries)
    audit(user(),"Register Payment",no,f"{typ} {amount}; document {doc['number'] if 'number' in doc.keys() else docid}; residual {residual-amount}")
    db.commit();return ok({"number":no,"residual":residual-amount,"status":new_status},201)

@bp.post("/transfers")
@require("transfer.create")
def transfer():
    d=request.get_json() or {};db=get_db();begin_write(db);sku=d.get("sku");qty=int(d.get("quantity",0));src=d.get("from_warehouse");dst=d.get("to_warehouse")
    if src==dst or qty<=0:return jsonify({"error":"Transfer tidak valid"}),400
    if not db.execute("SELECT 1 FROM products WHERE sku=?",(sku,)).fetchone() or not db.execute("SELECT 1 FROM warehouses WHERE code=?",(src,)).fetchone() or not db.execute("SELECT 1 FROM warehouses WHERE code=?",(dst,)).fetchone():return jsonify({"error":"SKU/gudang tidak ditemukan"}),404
    no=next_number("INT");cur=db.execute("INSERT INTO transfers(number,from_warehouse,to_warehouse,sku,quantity,status,created_by) VALUES(?,?,?,?,?,'Ready',?)",(no,src,dst,sku,qty,user()))
    audit(user(),"Create Internal Transfer",no,f"{src} -> {dst}; {sku} x {qty}");db.commit()
    return ok({"id":cur.lastrowid,"number":no,"status":"Ready"},201)

@bp.post("/transfers/<int:tid>/validate")
@require("transfer.validate")
def validate_transfer(tid):
    db=get_db();begin_write(db);t=db.execute("SELECT * FROM transfers WHERE id=?",(tid,)).fetchone()
    if not t:return jsonify({"error":"Transfer tidak ditemukan"}),404
    if t["status"]=="Done":return ok({"status":"Done","idempotent":True})
    if t["status"]!="Ready":return jsonify({"error":"Transfer bukan Ready"}),409
    src=db.execute("SELECT on_hand FROM stock WHERE sku=? AND warehouse_code=?",(t["sku"],t["from_warehouse"])).fetchone()
    reserved=db.execute("SELECT COALESCE(SUM(quantity),0) n FROM reservations WHERE sku=? AND warehouse_code=? AND active=1",(t["sku"],t["from_warehouse"])).fetchone()["n"]
    available=(src["on_hand"] if src else 0)-reserved
    if t["quantity"]>available:return jsonify({"error":f"Available di lokasi asal hanya {available}; reserved stock tidak boleh dipindahkan"}),409
    db.execute("UPDATE stock SET on_hand=on_hand-? WHERE sku=? AND warehouse_code=?",(t["quantity"],t["sku"],t["from_warehouse"]))
    db.execute("INSERT INTO stock(sku,warehouse_code,on_hand) VALUES(?,?,?) ON CONFLICT(sku,warehouse_code) DO UPDATE SET on_hand=on_hand+excluded.on_hand",(t["sku"],t["to_warehouse"],t["quantity"]))
    db.execute("UPDATE transfers SET status='Done',validated_at=CURRENT_TIMESTAMP WHERE id=?",(tid,))
    audit(user(),"Validate Internal Transfer",t["number"],"Company inventory quantity/value unchanged");db.commit()
    return ok({"status":"Done"})

@bp.post("/returns")
@require("returns.create")
def create_return():
    # Warehouse records physical inspection and the stock move. Finance posts the Credit Note separately.
    d=request.get_json() or {};db=get_db();begin_write(db);iid=int(d.get("invoice_id",0));sku=str(d.get("sku") or "").strip();qty=int(d.get("quantity",0))
    key=str(request.headers.get("Idempotency-Key") or d.get("idempotency_key") or "").strip() or None
    if key:
        existing=db.execute("SELECT * FROM returns WHERE idempotency_key=?",(key,)).fetchone()
        if existing:
            if (existing["invoice_id"],existing["sku"],existing["quantity"],existing["inspection_status"])!=(iid,sku,qty,str(d.get("inspection_status") or ("Saleable" if d.get("saleable",True) else "Rejected"))):
                return jsonify({"error":"Idempotency-Key sudah digunakan untuk payload retur yang berbeda"}),409
            return ok({"id":existing["id"],"number":existing["number"],"status":existing["status"],"idempotent":True})
    inv=db.execute("SELECT * FROM invoices WHERE id=? AND status IN ('Posted','Partial','Paid')",(iid,)).fetchone()
    if not inv or qty<=0:return jsonify({"error":"Invoice/quantity tidak valid"}),400
    line=db.execute("SELECT * FROM invoice_lines WHERE invoice_id=? AND sku=?",(iid,sku)).fetchone()
    if not line:return jsonify({"error":"SKU tidak ada pada invoice"}),404
    order_id=inv["order_id"]
    delivered=db.execute("SELECT COALESCE(SUM(dl.quantity),0) n FROM delivery_lines dl JOIN deliveries d ON d.id=dl.delivery_id WHERE d.order_id=? AND d.status='Done' AND dl.sku=?",(order_id,sku)).fetchone()["n"]
    returned_order=db.execute("SELECT COALESCE(SUM(r.quantity),0) n FROM returns r JOIN invoices ri ON ri.id=r.invoice_id WHERE ri.order_id=? AND r.sku=? AND r.status IN ('Received','Done')",(order_id,sku)).fetchone()["n"]
    returned_invoice=db.execute("SELECT COALESCE(SUM(quantity),0) n FROM returns WHERE invoice_id=? AND sku=? AND status IN ('Received','Done')",(iid,sku)).fetchone()["n"]
    remaining=min(delivered-returned_order,line["quantity"]-returned_invoice)
    if qty>remaining:return jsonify({"error":f"Return melebihi net delivered / uninvoiced return quantity; sisa {max(remaining,0)}"}),409
    inspection=str(d.get("inspection_status") or ("Saleable" if d.get("saleable",True) else "Rejected"))
    if inspection not in ("Saleable","Rejected"):return jsonify({"error":"inspection_status harus Saleable atau Rejected"}),400
    reason=str(d.get("quality_reason") or "").strip()
    if inspection=="Rejected" and not reason:return jsonify({"error":"Alasan retur tidak layak jual wajib diisi"}),400
    net=money(Decimal(line["net_amount"])*Decimal(qty)/Decimal(line["quantity"]));tax=tax_of(net);credit=net+tax
    no=next_number("RET")
    cur=db.execute("INSERT INTO returns(number,invoice_id,sku,quantity,status,credit_total,inspection_status,quality_reason,created_by,idempotency_key) VALUES(?,?,?,?,'Received',?,?,?,?,?)",(no,iid,sku,qty,credit,inspection,reason,user(),key))
    rid=cur.lastrowid
    stock_moved=0
    if inspection=="Saleable":
        so=db.execute("SELECT warehouse_code FROM sales_orders WHERE id=?",(order_id,)).fetchone()
        db.execute("UPDATE stock SET on_hand=on_hand+? WHERE sku=? AND warehouse_code=?",(qty,sku,so["warehouse_code"]))
        stock_moved=qty
    audit(user(),"Return Inspection + Stock Move",no,f"Invoice {inv['number']}; {sku} x {qty}; inspection {inspection}; stock restored {stock_moved}")
    db.commit();return ok({"id":rid,"number":no,"credit_total":credit,"net_amount":net,"tax_amount":tax,"status":"Received","stock_moved":stock_moved},201)

@bp.post("/returns/<int:rid>/validate")
@require("returns.validate")
def validate_return(rid):
    # Finance-only step: create the Credit Note and the balanced reversal journal.
    db=get_db();begin_write(db);r=db.execute("SELECT * FROM returns WHERE id=?",(rid,)).fetchone()
    if not r:return jsonify({"error":"Return tidak ditemukan"}),404
    if r["status"]=="Done":
        cn=db.execute("SELECT number,total FROM credit_notes WHERE return_id=?",(rid,)).fetchone()
        return ok({"status":"Done","credit_note_number":cn["number"] if cn else None,"idempotent":True})
    if r["status"]!="Received":return jsonify({"error":"Return harus berstatus Received setelah inspeksi Warehouse"}),409
    inv=db.execute("SELECT * FROM invoices WHERE id=?",(r["invoice_id"],)).fetchone()
    line=db.execute("SELECT * FROM invoice_lines WHERE invoice_id=? AND sku=?",(r["invoice_id"],r["sku"])).fetchone()
    net=money(Decimal(line["net_amount"])*Decimal(r["quantity"])/Decimal(line["quantity"]));tax=tax_of(net);credit=net+tax
    no=next_number("CN");db.execute("INSERT INTO credit_notes(number,return_id,invoice_id,status,net_amount,tax_amount,total) VALUES(?,?,?,'Posted',?,?,?)",(no,rid,r["invoice_id"],net,tax,credit))
    cnid=db.execute("SELECT last_insert_rowid() id").fetchone()["id"]
    gross_before_discount=money(Decimal(line["unit_price"])*Decimal(r["quantity"]))
    discount_amount=gross_before_discount-net
    entries=[("4100",gross_before_discount,0),("2200",tax,0),("1100",0,credit)]
    if discount_amount:entries.append(("4110",0,discount_amount))
    cost=0
    if r["inspection_status"]=="Saleable":
        cost=db.execute("SELECT standard_cost FROM products WHERE sku=?",(r["sku"],)).fetchone()["standard_cost"]*r["quantity"]
        entries.extend([("1200",cost,0),("5100",0,cost)])
    add_journal("Credit Note",cnid,entries)
    db.execute("UPDATE returns SET status='Done',credit_total=? WHERE id=?",(credit,rid))
    audit(user(),"Post Credit Note",no,f"Return {r['number']}; customer AR credit {credit}; COGS reversal {cost}")
    db.commit();return ok({"status":"Done","credit_note_number":no,"net_amount":net,"tax_amount":tax,"total":credit,"cogs_reversal":cost})

@bp.post("/leads")
@require("crm.create")
def create_lead():
    d=request.get_json() or {};db=get_db();begin_write(db);title=str(d.get("title") or "").strip();customer=d.get("customer_code") or None
    if not title:return jsonify({"error":"Nama Lead wajib diisi"}),400
    if customer and not db.execute("SELECT 1 FROM customers WHERE code=?",(customer,)).fetchone():return jsonify({"error":"Customer tidak ditemukan"}),400
    no=next_number("CRM");cur=db.execute("INSERT INTO leads(number,customer_code,title,stage,notes) VALUES(?,?,?,'New',?)",(no,customer,title,d.get("notes")))
    audit(user(),"Create Lead",no);db.commit();return ok({"id":cur.lastrowid,"number":no,"stage":"New"},201)

@bp.post("/leads/<int:lid>/stage")
@require("crm.update")
def update_lead_stage(lid):
    d=request.get_json() or {};db=get_db();begin_write(db);stage=str(d.get("stage") or "").strip();valid={"New","Qualified","Won","Lost"}
    if stage not in valid:return jsonify({"error":"Stage harus New, Qualified, Won, atau Lost"}),400
    lead=db.execute("SELECT * FROM leads WHERE id=?",(lid,)).fetchone()
    if not lead:return jsonify({"error":"Lead tidak ditemukan"}),404
    db.execute("UPDATE leads SET stage=? WHERE id=?",(stage,lid));audit(user(),"Update Lead Stage",lead["number"],f"{lead['stage']} -> {stage}");db.commit()
    return ok({"number":lead["number"],"stage":stage})

@bp.post("/leads/<int:lid>/quotations")
@require("crm.create")
def create_quotation(lid):
    d=request.get_json() or {};db=get_db();begin_write(db);lead=db.execute("SELECT * FROM leads WHERE id=?",(lid,)).fetchone()
    if not lead:return jsonify({"error":"Lead tidak ditemukan"}),404
    if lead["stage"] not in ("Qualified", "Won"):
        return jsonify({"error":"Lead harus Qualified atau Won sebelum dibuat Quotation"}),409
    customer=d.get("customer_code") or lead["customer_code"]
    if not customer or not db.execute("SELECT 1 FROM customers WHERE code=?",(customer,)).fetchone():return jsonify({"error":"Customer pada Quotation wajib valid"}),400
    lines=d.get("lines",[]);discount=float(d.get("discount_pct",0))
    if not lines or not 0<=discount<=100:return jsonify({"error":"Quotation perlu product line dan diskon valid"}),400
    prepared=[];subtotal=tax=0;seen=set()
    for line in lines:
        sku=line.get("sku");p=db.execute("SELECT * FROM products WHERE sku=?",(sku,)).fetchone();qty=int(line.get("quantity",0))
        if not p or qty<=0 or sku in seen:return jsonify({"error":"SKU/quantity tidak valid atau duplikat"}),400
        seen.add(sku);discount_factor=(Decimal("100")-Decimal(str(discount)))/Decimal("100")
        net=money(Decimal(qty*p["sales_price"])*discount_factor);tx=tax_of(net)
        prepared.append((sku,qty,p["sales_price"],discount,net,tx,net+tx));subtotal+=net;tax+=tx
    no=next_number("Q");cur=db.execute("INSERT INTO quotations(number,lead_id,customer_code,status,discount_pct,subtotal,tax,total,warehouse_code,created_by) VALUES(?,?,?,'Draft',?,?,?,?,?,?)",(no,lid,customer,discount,subtotal,tax,subtotal+tax,d.get("warehouse_code","WH-PKU"),user()))
    qid=cur.lastrowid
    for x in prepared:db.execute("INSERT INTO quotation_lines(quotation_id,sku,quantity,unit_price,discount_pct,subtotal,tax,total) VALUES(?,?,?,?,?,?,?,?)",(qid,*x))
    audit(user(),"Create Quotation",no,lead["number"]);db.commit();return ok({"id":qid,"number":no,"subtotal":subtotal,"tax":tax,"total":subtotal+tax},201)

@bp.post("/quotations/<int:qid>/convert")
@require("sales.create")
def convert_quotation(qid):
    db=get_db();begin_write(db);q=db.execute("SELECT * FROM quotations WHERE id=?",(qid,)).fetchone()
    if not q:return jsonify({"error":"Quotation tidak ditemukan"}),404
    if q["converted_order_id"]:
        so=db.execute("SELECT id,number,status FROM sales_orders WHERE id=?",(q["converted_order_id"],)).fetchone()
        return ok({"id":so["id"],"number":so["number"],"status":so["status"],"idempotent":True})
    if q["status"]!="Draft":return jsonify({"error":"Quotation bukan Draft"}),409
    no=next_number("S");cur=db.execute("INSERT INTO sales_orders(number,customer_code,status,discount_pct,subtotal,tax,total,warehouse_code,created_by,quotation_id) VALUES(?,?,'Draft',?,?,?,?,?,?,?)",(no,q["customer_code"],q["discount_pct"],q["subtotal"],q["tax"],q["total"],q["warehouse_code"],user(),qid))
    oid=cur.lastrowid
    for l in db.execute("SELECT * FROM quotation_lines WHERE quotation_id=?",(qid,)).fetchall():
        db.execute("INSERT INTO sales_order_lines(order_id,sku,quantity,unit_price,discount_pct,subtotal,tax,total) VALUES(?,?,?,?,?,?,?,?)",(oid,l["sku"],l["quantity"],l["unit_price"],l["discount_pct"],l["subtotal"],l["tax"],l["total"]))
    db.execute("UPDATE quotations SET status='Converted',converted_order_id=? WHERE id=?",(oid,qid));audit(user(),"Convert Quotation to SO",q["number"],no);db.commit()
    return ok({"id":oid,"number":no,"status":"Draft"},201)

@bp.post("/sales-orders/<int:oid>/revise")
@require("sales.confirm")
def revise_confirmed_so(oid):
    # Confirmed documents remain locked. This endpoint records a controlled revision request;
    # it deliberately does not mutate posted commercial values or inventory commitments.
    d=request.get_json() or {};db=get_db();begin_write(db);reason=str(d.get("reason") or "").strip()
    if session.get("user",{}).get("role")!="Owner":return jsonify({"error":"Revisi Sales Order Confirmed hanya dapat diajukan Owner"}),403
    if not reason:return jsonify({"error":"Alasan revisi wajib diisi"}),400
    so=db.execute("SELECT * FROM sales_orders WHERE id=?",(oid,)).fetchone()
    if not so:return jsonify({"error":"SO tidak ditemukan"}),404
    snapshot={k:so[k] for k in so.keys()}
    db.execute("INSERT INTO sales_order_revisions(order_id,actor,reason,before_json,after_json) VALUES(?,?,?,?,?)",(oid,user(),reason,json.dumps(snapshot),json.dumps(snapshot)))
    audit(user(),"Controlled SO Revision Request",so["number"],reason);db.commit()
    return ok({"status":"Revision Recorded; commercial values remain locked"})

@bp.get("/accounting/trial-balance")
@require("accounting.view")
def trial_balance():
    rows=get_db().execute("""SELECT account_code,SUM(debit) debit,SUM(credit) credit
      FROM journal_lines GROUP BY account_code ORDER BY account_code""").fetchall()
    out=rowdicts(rows)
    return ok({"lines":out,"total_debit":sum(x["debit"] for x in out),"total_credit":sum(x["credit"] for x in out),"balanced":sum(x["debit"] for x in out)==sum(x["credit"] for x in out)})

@bp.get("/reports")
@require("reports.view")
def reports():
    db=get_db()
    return ok({"sales_by_status":rowdicts(db.execute("SELECT status,COUNT(*) count,SUM(total) amount FROM sales_orders GROUP BY status").fetchall()),
               "purchase_by_status":rowdicts(db.execute("SELECT status,COUNT(*) count,SUM(total) amount FROM purchase_orders GROUP BY status").fetchall()),
               "stock_by_warehouse":rowdicts(db.execute("SELECT warehouse_code,SUM(on_hand) units FROM stock GROUP BY warehouse_code").fetchall())})

@bp.post("/seed/reset")
@require("*")
def reset_seed():
    # Owner-only destructive reset; rebuilds the baseline fixture.
    if session.get("user",{}).get("role")!="Owner":return jsonify({"error":"Owner only"}),403
    db=get_db();begin_write(db)
    for t in ["journal_lines","journal_entries","credit_notes","vendor_bill_lines","returns","transfers","payments","vendor_bills","invoice_lines","invoices","receipt_lines","receipts","purchase_order_lines","purchase_orders","quotation_lines","quotations","sales_order_revisions","delivery_lines","deliveries","sales_order_lines","sales_orders","reservations","leads","audit_logs","reorder_points","stock","vendor_pricelist","products","vendors","customers","warehouses","sequences","settings","users"]:
        db.execute(f"DELETE FROM {t}")
    db.commit()
    from .db import seed_db
    seed_db()
    return ok({"message":"Baseline reset berhasil"})


@bp.get("/products/analysis")
@require("reports.view")
def product_analysis():
    db = get_db()

    # Minimum stok bersifat opsional untuk percobaan
    raw_minimum = request.args.get("minimum")
    minimum = None

    if raw_minimum is not None:
        try:
            minimum = int(raw_minimum)
            if minimum < 0:
                raise ValueError()
        except ValueError:
            return jsonify({
                "error": "Minimum stok harus angka 0 atau lebih"
            }), 400

    # Ambil data produk dan stok dari database
    rows = db.execute("""
        SELECT
            p.sku,
            p.name,
            p.size,
            p.unit,
            p.sales_price,
            p.standard_cost,
            s.warehouse_code,
            s.on_hand,
            rp.min_available,
            COALESCE((
                SELECT SUM(r.quantity)
                FROM reservations r
                WHERE r.sku = s.sku
                  AND r.warehouse_code = s.warehouse_code
                  AND r.active = 1
            ), 0) AS reserved
        FROM products p
        JOIN stock s ON s.sku = p.sku
        LEFT JOIN reorder_points rp
        ON rp.sku = s.sku
        AND rp.warehouse_code = s.warehouse_code
        WHERE p.active = 1
        ORDER BY p.sku, s.warehouse_code
    """).fetchall()

    results = []

    for row in rows:
        product = dict(row)

        # Hitung stok yang tersedia
        product["available"] = (
            product["on_hand"] - product["reserved"]
        )

        # Hitung nilai persediaan
        product["stock_value"] = (
            product["on_hand"] * product["standard_cost"]
        )

        # Hitung potensi margin kotor per unit
        product["margin_per_unit"] = (
            product["sales_price"] - product["standard_cost"]
        )

        # Tentukan status stok
        if product["min_available"] is None:
            product["stock_status"] = "Belum diatur"
        elif product["available"] <= product["min_available"]:
            product["stock_status"] = "Stok menipis"
        else:
            product["stock_status"] = "Normal"

        results.append(product)

    return ok(results)


@bp.post("/products/reorder-point")
@require("products.configure")
def save_reorder_point():
    data = request.get_json(silent=True) or {}
    db = get_db(); begin_write(db)

    if not isinstance(data, dict):
        return jsonify({
            "error": "Format data tidak valid"
        }), 400

    sku = str(data.get("sku") or "").strip()
    warehouse = str(data.get("warehouse_code") or "").strip()
    minimum = data.get("min_available")

    # Validasi input
    if not sku or not warehouse:
        return jsonify({
            "error": "SKU dan gudang wajib diisi"
        }), 400

    if type(minimum) is not int or minimum < 0:
        return jsonify({
            "error": "Minimum stok harus bilangan bulat >= 0"
        }), 400

    # Pastikan produk dan gudang tersedia
    stock = db.execute("""
        SELECT 1 FROM stock
        WHERE sku = ? AND warehouse_code = ?
    """, (sku, warehouse)).fetchone()

    if not stock:
        return jsonify({
            "error": "Produk atau gudang tidak ditemukan"
        }), 404

    # Simpan atau perbarui minimum stok
    db.execute("""
        INSERT INTO reorder_points
            (sku, warehouse_code, min_available)
        VALUES (?, ?, ?)
        ON CONFLICT(sku, warehouse_code)
        DO UPDATE SET
            min_available = excluded.min_available
    """, (sku, warehouse, minimum))

    # Simpan riwayat perubahan
    audit(
        user(),
        "Set Minimum Stock",
        f"{sku}/{warehouse}",
        f"Minimum available: {minimum}"
    )

    db.commit()

    return ok({
        "sku": sku,
        "warehouse_code": warehouse,
        "min_available": minimum
    })


@bp.get("/products/performance")
@require("reports.view")
def products_performance():
    db = get_db()

    # Periode analisis: default 30 hari
    try:
        days = int(request.args.get("days", "30"))
    except (TypeError, ValueError):
        return jsonify({
            "error": "Periode harus berupa angka"
        }), 400

    if days < 1 or days > 365:
        return jsonify({
            "error": "Periode harus 1 sampai 365 hari"
        }), 400

    # 1. Ambil seluruh produk aktif
    products = db.execute("""
        SELECT
            sku,
            name,
            size,
            unit,
            sales_price,
            standard_cost
        FROM products
        WHERE active = 1
        ORDER BY sku
    """).fetchall()

    # 2. Ambil stok dan minimum stok per gudang
    stock_rows = db.execute("""
        SELECT
            s.sku,
            s.warehouse_code,
            s.on_hand,
            rp.min_available,
            COALESCE((
                SELECT SUM(r.quantity)
                FROM reservations r
                WHERE r.sku = s.sku
                  AND r.warehouse_code = s.warehouse_code
                  AND r.active = 1
            ), 0) AS reserved
        FROM stock s
        LEFT JOIN reorder_points rp
            ON rp.sku = s.sku
           AND rp.warehouse_code = s.warehouse_code
    """).fetchall()

    stock_by_sku = {}

    for row in stock_rows:
        stock_by_sku.setdefault(
            row["sku"], []
        ).append(dict(row))

    # 3. Hitung produk terkirim pada periode
    # Hanya Delivery berstatus Done
    delivery_rows = db.execute("""
        SELECT
            dl.sku,
            SUM(dl.quantity) AS total_sold,
            COUNT(DISTINCT d.id) AS delivery_count
        FROM delivery_lines dl
        JOIN deliveries d
            ON d.id = dl.delivery_id
        WHERE d.status = 'Done'
          AND d.validated_at IS NOT NULL
          AND datetime(d.validated_at) >= datetime('now', ?)
        GROUP BY dl.sku
    """, (f"-{days} days",)).fetchall()

    sales_by_sku = {
        row["sku"]: dict(row)
        for row in delivery_rows
    }

    total_delivered = sum(
        row["total_sold"] for row in delivery_rows
    )

    # 4. Hitung pendapatan dari Invoice Posted
    # SO Confirmed belum dianggap revenue
    invoice_rows = db.execute("""
        SELECT
            il.sku,
            SUM(il.quantity) AS invoiced_qty,
            SUM(il.net_amount) AS net_sales
        FROM invoice_lines il
        JOIN invoices i
            ON i.id = il.invoice_id
        WHERE i.status IN ('Posted','Partial','Paid')
        GROUP BY il.sku
    """).fetchall()

    invoice_by_sku = {
        row["sku"]: dict(row)
        for row in invoice_rows
    }

    # 5. Retur dicatat terpisah untuk evaluasi
    return_rows = db.execute("""
        SELECT
            r.sku,
            SUM(r.quantity) AS returned_qty,
            SUM(cn.net_amount) AS returned_net_amount,
            SUM(r.quantity * p.standard_cost) AS returned_cogs
        FROM returns r
        JOIN credit_notes cn ON cn.return_id = r.id AND cn.status = 'Posted'
        JOIN products p ON p.sku = r.sku
        WHERE r.status = 'Done'
        GROUP BY r.sku
    """).fetchall()

    returns_by_sku = {
        row["sku"]: dict(row)
        for row in return_rows
    }

    results = []

    for p in products:
        sku = p["sku"]
        locations = stock_by_sku.get(sku, [])

        # Jumlah stok seluruh lokasi
        on_hand = sum(
            r["on_hand"] for r in locations
        )

        reserved = sum(
            r["reserved"] for r in locations
        )

        available = on_hand - reserved

        # Penjualan berdasarkan Delivery Done
        sales = sales_by_sku.get(sku, {})

        total_sold = sales.get("total_sold", 0)
        delivery_count = sales.get("delivery_count", 0)

        # Nilai inventory
        stock_value = (
            on_hand * p["standard_cost"]
        )

        # Margin potensial per unit
        margin_per_unit = (
            p["sales_price"] - p["standard_cost"]
        )

        # Keuntungan berdasarkan Posted Invoice
        invoice = invoice_by_sku.get(sku)

        returned = returns_by_sku.get(sku, {})
        if invoice is None:
            net_sales = None
            estimated_cogs = None
            gross_profit = None
            profit_margin = None
        else:
            net_sales = invoice["net_sales"] - returned.get("returned_net_amount", 0)

            estimated_cogs = (
                invoice["invoiced_qty"] * p["standard_cost"]
                - returned.get("returned_cogs", 0)
            )

            gross_profit = (
                net_sales - estimated_cogs
            )

            profit_margin = (
                round(gross_profit / net_sales * 100, 2)
                if net_sales > 0 else None
            )

        # Cek lokasi dengan stok menipis
        low_stock_locations = []
        configured_locations = 0

        for r in locations:
            minimum = r["min_available"]

            if minimum is None:
                continue

            configured_locations += 1

            location_available = (
                r["on_hand"] - r["reserved"]
            )

            if location_available <= minimum:
                low_stock_locations.append(
                    r["warehouse_code"]
                )

        # Klasifikasi pergerakan produk
        if total_delivered == 0:
            movement_status = "Data belum cukup"
        elif total_sold == 0:
            movement_status = "0 terkirim - perlu evaluasi"
        else:
            movement_status = "Ada pengiriman"

        # Rekomendasi untuk Finance
        if configured_locations == 0:
            recommendation = (
                "Minimum stok belum diatur"
            )

        elif low_stock_locations and total_sold > 0:
            recommendation = (
                "Pertimbangkan restock"
            )

        elif low_stock_locations:
            recommendation = (
                "Stok menipis - evaluasi kebutuhan"
            )

        else:
            recommendation = (
                "Stok cukup pada lokasi terkonfigurasi"
            )

        results.append({
            "sku": sku,
            "product": (
                f'{p["name"]} {p["size"] or ""}'
            ).strip(),

            "on_hand": on_hand,
            "reserved": reserved,
            "available": available,
            "stock_value": stock_value,

            "total_sold_period": total_sold,
            "delivery_count": delivery_count,
            "movement_status": movement_status,

            "margin_per_unit": margin_per_unit,

            "posted_net_sales": net_sales,
            "estimated_cogs": estimated_cogs,
            "estimated_gross_profit": gross_profit,
            "estimated_profit_margin_pct": profit_margin,

            "returned_qty": returned.get("returned_qty", 0),

            "low_stock_locations": (
                ", ".join(low_stock_locations)
                if low_stock_locations else "—"
            ),

            "restock_recommendation": recommendation
        })

    # 6. Ranking produk paling banyak terkirim
    best_sellers = sorted(
        [
            x for x in results
            if x["total_sold_period"] > 0
        ],
        key=lambda x: (
            -x["total_sold_period"], x["sku"]
        )
    )[:5]

    # 7. Produk dengan pengiriman paling rendah
    # Tidak otomatis berarti produk tidak laku
    if total_delivered > 0:
        low_movement = sorted(
            results,
            key=lambda x: (
                x["total_sold_period"], x["sku"]
            )
        )[:5]
    else:
        low_movement = []

    # 8. Produk yang perlu ditinjau untuk restock
    restock_candidates = [
        x for x in results
        if x["restock_recommendation"]
        == "Pertimbangkan restock"
    ]

    return ok({
        "period_days": days,
        "has_delivery_history": total_delivered > 0,
        "total_delivered_units": total_delivered,
        "best_sellers": best_sellers,
        "low_movement_products": low_movement,
        "restock_candidates": restock_candidates,
        "products": results,
        "note": (
            "Produk terlaris dihitung dari Delivery Done. "
            "Keuntungan adalah estimasi berdasarkan "
            "Invoice Posted dikurangi Credit Note Posted, "
            "dengan COGS berdasarkan standard cost master saat ini."
        )
    })


@bp.get("/contacts/profitability")
@require("reports.view")
def contacts_profitability():
    db = get_db()

    # Ambil semua customer aktif
    customers = db.execute("""
        SELECT code, name, opening_ar, credit_limit
        FROM customers
        WHERE active = 1
        ORDER BY code
    """).fetchall()

    # Penjualan hanya dari Invoice Posted
    # Dipisah dari retur supaya tidak double counting
    invoice_rows = db.execute("""
        SELECT
            so.customer_code AS customer_code,
            SUM(il.net_amount) AS invoiced_net_sales,
            SUM(
                il.quantity * p.standard_cost
            ) AS estimated_cogs
        FROM invoices i
        JOIN sales_orders so
            ON so.id = i.order_id
        JOIN invoice_lines il
            ON il.invoice_id = i.id
        JOIN products p
            ON p.sku = il.sku
        WHERE i.status IN ('Posted','Partial','Paid')
        GROUP BY so.customer_code
    """).fetchall()

    invoice_by_customer = {
        r["customer_code"]: dict(r)
        for r in invoice_rows
    }

    # Piutang dari Invoice Posted yang belum lunas
    ar_rows = db.execute("""
        SELECT
            so.customer_code AS customer_code,
            COUNT(*) AS posted_invoice_count,
            SUM(MAX(i.total-i.paid_amount-COALESCE(cn.credited,0),0)) AS unpaid_invoice_ar
        FROM invoices i
        JOIN sales_orders so ON so.id = i.order_id
        LEFT JOIN (SELECT invoice_id,SUM(total) credited FROM credit_notes WHERE status='Posted' GROUP BY invoice_id) cn ON cn.invoice_id=i.id
        WHERE i.status IN ('Posted','Partial','Paid')
        GROUP BY so.customer_code
    """).fetchall()

    ar_by_customer = {
        r["customer_code"]: dict(r)
        for r in ar_rows
    }

    # Retur yang sudah Done
    return_rows = db.execute("""
        SELECT
            so.customer_code AS customer_code,
            r.quantity,
            r.credit_total,
            cn.net_amount AS credit_net_amount,
            p.standard_cost
        FROM returns r
        JOIN credit_notes cn ON cn.return_id = r.id AND cn.status='Posted'
        JOIN invoices i
            ON i.id = r.invoice_id
        JOIN sales_orders so
            ON so.id = i.order_id
        JOIN products p
            ON p.sku = r.sku
        WHERE r.status = 'Done'
          AND i.status IN ('Posted','Partial','Paid')
    """).fetchall()

    returns_by_customer = {}

    for r in return_rows:
        ret = returns_by_customer.setdefault(
            r["customer_code"],
            {
                "returned_units": 0,
                "returned_net_est": 0,
                "returned_cost_est": 0,
                "credit_note_gross": 0
            }
        )

        ret["returned_units"] += r["quantity"]

        # credit_total sudah termasuk pajak
        ret["returned_net_est"] += int(r["credit_net_amount"])

        ret["returned_cost_est"] += (
            r["quantity"] * r["standard_cost"]
        )

        ret["credit_note_gross"] += r["credit_total"]

    results = []

    for c in customers:
        code = c["code"]

        invoice = invoice_by_customer.get(code)
        ar = ar_by_customer.get(code, {})
        ret = returns_by_customer.get(code, {})

        opening_ar = c["opening_ar"]

        unpaid_invoice_ar = ar.get(
            "unpaid_invoice_ar", 0
        )

        outstanding_ar = (
            opening_ar + unpaid_invoice_ar
        )

        # Jangan mengarang keuntungan jika
        # belum ada Invoice Posted
        if invoice is None:
            net_sales = None
            estimated_cogs = None
            gross_profit = None
            profit_margin_pct = None

            profit_status = (
                "Belum ada Invoice Posted"
            )

        else:
            # Penjualan bersih setelah retur
            net_sales = (
                invoice["invoiced_net_sales"]
                - ret.get("returned_net_est", 0)
            )

            # Estimasi COGS setelah retur
            estimated_cogs = (
                invoice["estimated_cogs"]
                - ret.get("returned_cost_est", 0)
            )

            gross_profit = (
                net_sales - estimated_cogs
            )

            profit_margin_pct = (
                round(
                    gross_profit / net_sales * 100,
                    2
                )
                if net_sales > 0 else None
            )

            if gross_profit > 0:
                profit_status = "Untung (estimasi)"

            elif gross_profit < 0:
                profit_status = "Rugi (estimasi)"

            else:
                profit_status = "Impas (estimasi)"

        results.append({
            "customer_code": code,
            "customer_name": c["name"],

            "posted_invoice_count": ar.get(
                "posted_invoice_count", 0
            ),

            "net_sales": net_sales,
            "estimated_cogs": estimated_cogs,
            "estimated_gross_profit": gross_profit,
            "estimated_margin_pct": profit_margin_pct,
            "profit_status": profit_status,

            "opening_ar": opening_ar,
            "unpaid_invoice_ar": unpaid_invoice_ar,
            "outstanding_ar": outstanding_ar,
            "credit_limit": c["credit_limit"],

            "returned_units": ret.get(
                "returned_units", 0
            ),

            "credit_note_gross": ret.get(
                "credit_note_gross", 0
            )
        })

    # Ranking customer paling menguntungkan
    profitable = sorted(
        [
            r for r in results
            if r["estimated_gross_profit"] is not None
            and r["estimated_gross_profit"] > 0
        ],
        key=lambda r: (
            -r["estimated_gross_profit"],
            r["customer_code"]
        )
    )

    # Customer dengan estimasi laba negatif
    losses = sorted(
        [
            r for r in results
            if r["estimated_gross_profit"] is not None
            and r["estimated_gross_profit"] < 0
        ],
        key=lambda r: (
            r["estimated_gross_profit"],
            r["customer_code"]
        )
    )

    customers_with_data = sum(
        r["posted_invoice_count"] > 0
        for r in results
    )

    return ok({
        "summary": {
            "customer_count": len(results),

            "customers_with_posted_invoice":
                customers_with_data,

            "customers_without_posted_invoice":
                len(results) - customers_with_data,

            "total_outstanding_ar": sum(
                r["outstanding_ar"]
                for r in results
            ),

            "total_estimated_gross_profit": (
                sum(
                    r["estimated_gross_profit"] or 0
                    for r in results
                )
                if customers_with_data else None
            )
        },

        "most_profitable": profitable[:5],
        "loss_making": losses,
        "customers": results,

        "note": (
            "Profit merupakan ESTIMASI kumulatif "
            "dari Invoice Posted dikurangi Return Done. "
            "COGS menggunakan standard cost saat ini, "
            "bukan biaya historis. "
            "Piutang = opening AR + sisa Invoice Posted. "
            "Retur belum otomatis mengurangi AR "
            "dalam starter ERP ini. "
            "Opening AR tidak dihitung sebagai laba."
        )
    })
