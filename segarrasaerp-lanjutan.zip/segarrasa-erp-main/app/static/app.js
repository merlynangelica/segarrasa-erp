const $ = s => document.querySelector(s); let currentUser = null, currentPage = "dashboard";
const titles = { dashboard: "Dashboard", customers: "Contacts", products: "Products", sales: "Sales Orders", purchase: "Purchase Orders", stock: "Inventory", deliveries: "Delivery Orders", receipts: "Receipts & Quality", invoices: "Customer Invoices", bills: "Vendor Bills", transfers: "Internal Transfers", returns: "Returns & Credit Notes", journals: "Accounting", leads: "CRM Pipeline", quotations: "Quotations", audit: "Audit Log" };
const fmt = n => "Rp " + Number(n || 0).toLocaleString("id-ID");
async function api(path, opts = {}) { let r = await fetch("/api" + path, { headers: { "Content-Type": "application/json" }, ...opts }); let d = await r.json(); if (!r.ok) throw Error(d.error || "Request failed"); return d }
function notice(msg, error = false) { $("#notice").innerHTML = `<div class="notice ${error ? "error" : ""}">${msg}</div>`; setTimeout(() => $("#notice").innerHTML = "", 5000) }
$("#loginForm").addEventListener("submit", async e => { e.preventDefault(); let f = new FormData(e.target); try { let d = await api("/login", { method: "POST", body: JSON.stringify(Object.fromEntries(f)) }); currentUser = d.user; boot() } catch (err) { $("#loginError").textContent = err.message } });
async function boot() {
    $("#login").classList.add("hidden"); $("#app").classList.remove("hidden"); $("#userName").textContent = currentUser.name; $("#userRole").textContent = currentUser.role;
    const visible = {
        Owner: ["dashboard", "customers", "products", "sales", "purchase", "stock", "deliveries", "receipts", "invoices", "bills", "transfers", "returns", "journals", "leads", "quotations", "audit"],
        Sales: ["dashboard", "customers", "products", "sales", "deliveries", "leads", "quotations"],
        Warehouse: ["dashboard", "products", "purchase", "stock", "deliveries", "receipts", "transfers", "returns"],
        Procurement: ["dashboard", "customers", "products", "purchase", "receipts"],
        Quality: ["dashboard", "products", "receipts"],
        Finance: ["dashboard", "customers", "products", "sales", "deliveries", "invoices", "bills", "returns", "journals", "audit"]
    };
    document.querySelectorAll("#nav button").forEach(b => { b.style.display = visible[currentUser.role]?.includes(b.dataset.page) ? "flex" : "none" });
    await show("dashboard");
}
$("#logout").onclick = async () => { await api("/logout", { method: "POST" }); location.reload() };
$("#nav").addEventListener("click", e => { let b = e.target.closest("button[data-page]"); if (!b) return; document.querySelectorAll("#nav button").forEach(x => x.classList.remove("active")); b.classList.add("active"); show(b.dataset.page) });
function moneyCell(v) { return typeof v === "number" && Math.abs(v) >= 1000 ? fmt(v) : v ?? "—" }
function table(rows) { if (!rows || !rows.length) return '<div class="empty">Belum ada data.</div>'; let keys = Object.keys(rows[0]); return `<div class="table-wrap"><table><thead><tr>${keys.map(k => `<th>${k.replaceAll("_", " ")}</th>`).join("")}</tr></thead><tbody>${rows.map(r => `<tr>${keys.map(k => `<td>${k === "status" ? `<span class="badge ${String(r[k]).toLowerCase().replaceAll(" ", "-")}">${r[k]}</span>` : moneyCell(r[k])}</td>`).join("")}</tr>`).join("")}</tbody></table></div>` }
async function setMinimumStock() {
    const sku = prompt("Masukkan SKU produk:");
    if (sku === null) return;

    const warehouse = prompt(
        "Masukkan gudang: WH-PKU atau OUT-MRP"
    );
    if (warehouse === null) return;

    const input = prompt("Masukkan minimum stok:");
    if (input === null) return;

    const minimum = Number(input);

    if (
        !sku.trim() ||
        !["WH-PKU", "OUT-MRP"].includes(
            warehouse.trim().toUpperCase()
        ) ||
        input.trim() === "" ||
        !Number.isSafeInteger(minimum) ||
        minimum < 0
    ) {
        notice("Data minimum stok tidak valid", true);
        return;
    }

    try {
        await api("/products/reorder-point", {
            method: "POST",
            body: JSON.stringify({
                sku: sku.trim().toUpperCase(),
                warehouse_code: warehouse.trim().toUpperCase(),
                min_available: minimum
            })
        });

        await show("products");
        notice("Minimum stok berhasil disimpan!");
    } catch (error) {
        notice(error.message, true);
    }
}

function productStockTable(rows) {
    return table(rows.map(p => ({
        Produk: `${p.name} ${p.size || ""}`.trim(),
        SKU: p.sku,
        Gudang: p.warehouse_code,
        "On Hand": p.on_hand,
        Reserved: p.reserved,
        Tersedia: p.available,
        Minimum: p.min_available == null
            ? "Belum diatur"
            : p.min_available,
        Status: p.stock_status || "Belum diketahui",
        "Nilai Stok": fmt(p.stock_value)
    })));
}
function productFinanceTable(rows) {
    return table(rows.map(p => {
        const terkirim =
            p.total_sold_period ??
            p.delivered_units_period ??
            0;

        const stok =
            p.available ??
            p.available_all_locations ??
            0;

        const profit =
            p.estimated_gross_profit ??
            p.estimated_gross_profit_lifetime;

        const saran =
            p.restock_recommendation ??
            p.restock_advice ??
            "Belum dapat dinilai";

        const low = p.low_stock_locations;

        const status =
            String(saran).toLowerCase().includes("minimum")
                ? "Minimum belum diatur"
                : low && low !== "—"
                    ? `Menipis: ${low}`
                    : "Tidak ada alert";

        return {
            Produk: `${p.product} (${p.sku})`,
            Stok: `${stok} unit`,
            "Terkirim 30 Hari": `${terkirim} unit`,
            "Est. Laba Kumulatif":
                profit == null
                    ? "Belum ada invoice"
                    : fmt(profit),
            "Status Stok": status,
            Rekomendasi: saran
        };
    }));
}
async function show(page) {
    currentPage = page; $("#pageTitle").textContent = titles[page] || page; $("#heading").textContent = titles[page] || page; $("#subheading").textContent = page === "dashboard" ? "Ringkasan operasional PT Segar Rasa Riau." : "Kelola data dan dokumen lintas modul."; $("#actions").innerHTML = ""; $("#pageContent").innerHTML = '<div class="empty">Loading…</div>';
    try {
        if (page === "dashboard") {
            let d = await api("/dashboard");
            const kpis = [
                metric("Total On Hand", d.on_hand + " unit", "Stok seluruh lokasi"),
                metric("Reserved", d.reserved + " unit", "Alokasi Sales Order aktif"),
                metric("Available", d.available + " unit", "On Hand − Reserved")
            ];
            if (d.stock_value !== undefined) kpis.push(metric("Stock Value", fmt(d.stock_value), "Standard cost"));
            if (d.open_sales_orders !== undefined) kpis.push(metric("Open Sales Orders", d.open_sales_orders, "Confirmed, belum selesai"));
            if (d.open_purchase_orders !== undefined) kpis.push(metric("Open Purchase Orders", d.open_purchase_orders, "RFQ / Pending / Confirmed"));
            if (d.posted_invoices !== undefined) {
                kpis.push(metric("Posted Invoices", d.posted_invoices, "Invoice yang sudah di-post"));
                kpis.push(metric("Revenue", fmt(d.revenue), "Net invoice posted − Credit Note"));
                kpis.push(metric("Accounts Receivable", fmt(d.ar), "Opening AR + residual invoice"));
                kpis.push(metric("Accounts Payable", fmt(d.ap), "Opening AP + residual vendor bill"));
                kpis.push(metric("Open Customer Invoices", d.open_customer_invoices, "Menunggu pembayaran"));
                kpis.push(metric("Open Vendor Bills", d.open_vendor_bills, "Menunggu pembayaran"));
            }
            if (d.open_leads !== undefined) kpis.push(metric("Open Leads", d.open_leads, "New / Qualified"));
            if (d.pending_quality_checks !== undefined) kpis.push(metric("Pending Quality Checks", d.pending_quality_checks, "Receipt menunggu inspeksi"));
            const quick = {
                Owner: ["sales", "purchase", "stock", "invoices", "bills", "journals", "leads", "audit"],
                Sales: ["sales", "deliveries", "leads", "quotations", "customers"],
                Warehouse: ["stock", "purchase", "deliveries", "receipts", "transfers", "returns"],
                Procurement: ["purchase", "receipts", "products", "customers"],
                Quality: ["receipts", "products"],
                Finance: ["sales", "deliveries", "invoices", "bills", "returns", "journals", "audit", "customers"]
            }[currentUser.role] || [];
            $("#pageContent").innerHTML = `<div class="grid">${kpis.join("")}</div>
 <div class="split"><div class="panel"><h3>Quick access</h3>${quick.map(p => `<div class="list-row"><span>${titles[p] || p}</span><button class="btn" onclick="show('${p}')">Open →</button></div>`).join("")}</div>
 <div class="panel"><h3>Recent activity</h3>${d.recent_audit.map(x => `<div class="list-row"><span><b>${x.action}</b><br><small>${x.actor} · ${x.document_ref || "—"}</small></span><small>${x.created_at}</small></div>`).join("")}</div></div>`;
        } else if (["customers", "products"].includes(page)) {
            let data = await api("/masters/" + page);
            $("#pageContent").innerHTML = table(data);

            if (page === "products" && ["Finance", "Owner"].includes(currentUser.role)) {
                let analysis = await api("/products/analysis");

                $("#pageContent").innerHTML += `
            <div class="panel">
                <h3>Product Stock Analysis</h3>
                <p>
                    Analisis stok, reservasi, dan nilai persediaan
                    berdasarkan SKU dan gudang.
                </p>
                ${productStockTable(analysis)}
            </div>
        `;
                if (currentUser.role === "Owner") {
                    $("#actions").innerHTML = `
        <button class="btn" onclick="setMinimumStock()">
            Atur Minimum Stok
        </button>
        `;
                }
                const performance = await api(
                    "/products/performance?days=30"
                );

                $("#pageContent").innerHTML += `
                    <div class="panel">
                        <h3>Product Performance — 30 Hari</h3>

                        <p>
                            Analisis produk berdasarkan pengiriman
                            yang sudah divalidasi dan data keuangan.
                        </p>

                        ${performance.has_delivery_history
                        ? `
                                <h4>Top 5 Best-Selling Products</h4>
                                ${productFinanceTable(performance.best_sellers)}

                                <h4>
                                    Produk dengan Pengiriman Terendah
                                </h4>
                                <p>
                                    Produk berikut perlu dievaluasi,
                                    bukan otomatis dianggap tidak laku.
                                </p>
                                ${productFinanceTable(
                            performance.low_movement_products
                        )}
                            `
                        : `
                                <div class="empty">
                                    Belum ada Delivery Done dalam
                                    30 hari terakhir.
                                    Ranking produk belum tersedia.
                                </div>
                            `
                    }

                        <h4>Restock Recommendation</h4>

                        ${performance.restock_candidates.length > 0
                        ? productFinanceTable(performance.restock_candidates)
                        : `
                                <div class="empty">
                                    Belum ada produk yang memenuhi
                                    kriteria rekomendasi restock.
                                </div>
                            `
                    }

                        <h4>All Product Performance</h4>

                        ${productFinanceTable(performance.products)}

                        <p>
                            <small>${performance.note}</small>
                        </p>
                    </div>
                `;

            }
            if (page === "customers" && ["Finance", "Owner"].includes(currentUser.role)) {

                const report = await api(
                    "/contacts/profitability"
                );

                // Susun kolom supaya mudah dibaca Finance
                const view = rows => table(
                    rows.map(c => ({
                        customer:
                            `${c.customer_code} — ${c.customer_name}`,

                        total_sales: c.net_sales,

                        estimated_cogs: c.estimated_cogs,

                        gross_profit: c.estimated_gross_profit,

                        margin:
                            c.estimated_margin_pct === null
                                ? "—"
                                : `${c.estimated_margin_pct}%`,

                        outstanding_ar: c.outstanding_ar,

                        profit_status: c.profit_status
                    }))
                );

                const s = report.summary;

                $("#pageContent").innerHTML += `
                    <div class="panel">

                        <h3>
                            Customer Profitability Analysis — Finance
                        </h3>

                        <p>
                            Analisis keuntungan berdasarkan
                            Invoice Posted, bukan Sales Order Draft.
                        </p>

                        <div class="grid">

                            ${metric(
                    "Customer",
                    s.customer_count,
                    "Total customer aktif"
                )}

                            ${metric(
                    "Sudah Ada Invoice",
                    s.customers_with_posted_invoice,
                    "Invoice Posted"
                )}

                            ${metric(
                    "Total Piutang",
                    fmt(s.total_outstanding_ar),
                    "Saldo awal + invoice belum lunas"
                )}

                            ${metric(
                    "Est. Laba Kotor",
                    s.total_estimated_gross_profit === null
                        ? "Belum ada data"
                        : fmt(s.total_estimated_gross_profit),
                    "Belum termasuk biaya operasional"
                )}

                        </div>

                        <h4>Customer Paling Menguntungkan</h4>

                        ${report.most_profitable.length
                        ? view(report.most_profitable)
                        : `
                                    <div class="empty">
                                        Belum ada customer dengan
                                        laba positif berdasarkan
                                        Invoice Posted.
                                    </div>
                                `
                    }

                        <h4>Customer Merugikan (Estimasi)</h4>

                        ${report.loss_making.length
                        ? view(report.loss_making)
                        : `
                                    <div class="empty">
                                        Belum ada customer dengan
                                        estimasi laba negatif
                                        dari transaksi yang tersedia.
                                    </div>
                                `
                    }
                            <h4>Saldo Piutang Tertinggi</h4>

                            <p>
                                Customer diurutkan berdasarkan saldo piutang
                                terbesar untuk membantu Finance memantau
                                penagihan. Saldo belum tentu jatuh tempo.
                            </p>

                            ${view(
                        [...report.customers]
                            .filter(c => c.outstanding_ar > 0)
                            .sort((a, b) =>
                                b.outstanding_ar - a.outstanding_ar
                            )
                            .slice(0, 5)
                    )}
                        <h4>Analisis Semua Customer</h4>

                        ${view(report.customers)}

                        <p>
                            <small>${report.note}</small>
                        </p>

                    </div>
                `;
            }
        }
        else if (page === "stock") { let d = await api("/stock"); $("#pageContent").innerHTML = table(d) }
        else { let kind = { sales: "sales", purchase: "purchase", deliveries: "deliveries", receipts: "receipts", invoices: "invoices", bills: "bills", transfers: "transfers", returns: "returns", journals: "journals", leads: "leads", quotations: "quotations", audit: "audit" }[page]; let d = await api("/documents/" + kind); $("#pageContent").innerHTML = table(d) }
        if (page === "journals") { let tb = await api("/accounting/trial-balance"); $("#pageContent").innerHTML += `<div class="panel"><h3>Trial Balance</h3>${table(tb.lines)}<b>Total Debit: ${fmt(tb.total_debit)} · Total Credit: ${fmt(tb.total_credit)}</b></div>` }
    } catch (err) { $("#pageContent").innerHTML = `<div class="notice error">${err.message}</div>` }
}
function metric(label, value, hint) { return `<div class="metric"><div class="label">${label}</div><div class="value">${value}</div><div class="hint">${hint}</div></div>` }
function openModal(title, body, submit) { let m = document.createElement("div"); m.className = "modal-backdrop"; m.innerHTML = `<div class="modal"><div class="modal-head"><h3>${title}</h3><button class="btn" id="closeModal">✕</button></div><div>${body}</div><div class="modal-actions"><button class="btn" id="cancelModal">Cancel</button><button class="btn primary" id="submitModal">Save</button></div></div>`; document.body.append(m); m.querySelectorAll("#closeModal,#cancelModal").forEach(b => b.onclick = () => m.remove()); m.querySelector("#submitModal").onclick = async () => { try { await submit(m); m.remove(); await show(currentPage); notice("Dokumen berhasil diproses.") } catch (e) { notice(e.message, true) } } }
async function openCreate(type) {
    if (type === "sales") { let [cs, ps] = await Promise.all([api("/masters/customers"), api("/masters/products")]); openModal("New Sales Order", `<div class="form-grid"><div><label>Customer</label><select id="customer">${cs.map(x => `<option value="${x.code}">${x.code} · ${x.name}</option>`)}</select></div><div><label>Discount %</label><input id="discount" type="number" value="0" min="0" max="100"></div><div><label>Warehouse</label><select id="warehouse"><option>WH-PKU</option><option>OUT-MRP</option></select></div><div><label>Product</label><select id="sku">${ps.map(x => `<option value="${x.sku}">${x.sku} · ${x.name} (${fmt(x.sales_price)})</option>`)}</select></div><div><label>Quantity</label><input id="qty" type="number" value="1" min="1"></div></div>`, async m => { let d = await api("/sales-orders", { method: "POST", body: JSON.stringify({ customer_code: m.querySelector("#customer").value, discount_pct: +m.querySelector("#discount").value, warehouse_code: m.querySelector("#warehouse").value, lines: [{ sku: m.querySelector("#sku").value, quantity: +m.querySelector("#qty").value }] }) }); notice(`Created ${d.number} · ${fmt(d.total)}`) }) }
    if (type === "purchase") { let [vs, ps] = await Promise.all([api("/masters/vendors"), api("/masters/products")]); openModal("New RFQ / Purchase Order", `<div class="form-grid"><div><label>Vendor</label><select id="vendor">${vs.map(x => `<option value="${x.code}">${x.code} · ${x.name}</option>`)}</select></div><div><label>Product</label><select id="sku">${ps.map(x => `<option value="${x.sku}">${x.sku} · ${x.name}</option>`)}</select></div><div><label>Quantity</label><input id="qty" type="number" value="1" min="1"></div><div><label>Unit Cost (IDR)</label><input id="cost" type="number" value="9000"></div></div>`, async m => { let d = await api("/purchase-orders", { method: "POST", body: JSON.stringify({ vendor_code: m.querySelector("#vendor").value, lines: [{ sku: m.querySelector("#sku").value, quantity: +m.querySelector("#qty").value, unit_cost: +m.querySelector("#cost").value }] }) }); notice(`Created ${d.number} · ${fmt(d.total)}`) }) }
    if (type === "transfers") { let ps = await api("/masters/products"); openModal("Internal Transfer", `<div class="form-grid"><div><label>SKU</label><select id="sku">${ps.map(x => `<option value="${x.sku}">${x.sku}</option>`)}</select></div><div><label>Quantity</label><input id="qty" type="number" min="1" value="1"></div><div><label>From</label><select id="src"><option>WH-PKU</option><option>OUT-MRP</option></select></div><div><label>To</label><select id="dst"><option>OUT-MRP</option><option>WH-PKU</option></select></div></div>`, async m => api("/transfers", { method: "POST", body: JSON.stringify({ sku: m.querySelector("#sku").value, quantity: +m.querySelector("#qty").value, from_warehouse: m.querySelector("#src").value, to_warehouse: m.querySelector("#dst").value }) })) }
}
async function confirmFlow() { let id = prompt("Masukkan database ID Sales Order (bukan nomor dokumen):"); if (!id) return; try { await api(`/sales-orders/${id}/confirm`, { method: "POST" }); notice("Sales Order confirmed & stock reserved."); show("sales") } catch (e) { notice(e.message, true) } }
(async () => { try { let s = await api("/session"); if (s.authenticated) { currentUser = s.user; boot() } } catch (e) { } })();
