/* Additional end-to-end workflow controls. Kept separate so the team's original app.js stays intact. */
(() => {
  const baseShow = window.show;
  const esc = value => String(value ?? "").replace(/[&<>"']/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[ch]));
  const askId = (label) => {
    const raw = prompt(`${label}\nMasukkan database ID (lihat kolom id pada tabel):`);
    if (raw === null) return null;
    const id = Number(raw);
    if (!Number.isSafeInteger(id) || id <= 0) throw new Error("Database ID harus bilangan bulat positif.");
    return id;
  };
  const send = async (path, method="POST", body=null) => api(path, {method, ...(body === null ? {} : {body: JSON.stringify(body)})});
  const action = (label, name, style="") => `<button class="btn ${style}" data-workflow="${name}">${label}</button>`;
  function addActions(page) {
    const role = currentUser?.role;
    let html = "";
    if (page === "sales") {
      if (role === "Sales" || role === "Owner") html += action("＋ Create Sales Order", "create-sales", "primary") + action("Confirm SO", "confirm-so");
    }
    if (page === "purchase") {
      if (role === "Procurement" || role === "Owner") html += action("＋ Create RFQ / PO", "create-po", "primary") + action("Request / Confirm PO", "confirm-po");
      if (role === "Owner") html += action("Approve Pending PO", "approve-po");
    }
    if (page === "deliveries" && (role === "Warehouse" || role === "Owner")) html += action("＋ Create Delivery", "create-delivery") + action("Validate Delivery", "validate-delivery", "primary");
    if (page === "receipts") {
      if (role === "Warehouse" || role === "Owner") html += action("＋ Create Receipt", "create-receipt", "primary") + action("Validate Receipt", "validate-receipt");
      if (role === "Quality" || role === "Owner") html += action("Quality Check Pass / Fail", "quality-check");
      if (role === "Finance" || role === "Owner") html += action("Create Vendor Bill", "create-bill");
    }
    if (page === "invoices" && (role === "Finance" || role === "Owner")) html += action("＋ Invoice from Delivery", "create-invoice", "primary") + action("Post Invoice", "post-invoice") + action("Register Customer Payment", "customer-payment");
    if (page === "bills" && (role === "Finance" || role === "Owner")) html += action("＋ Bill from Receipt", "create-bill", "primary") + action("Post Vendor Bill", "post-bill") + action("Register Vendor Payment", "vendor-payment");
    if (page === "transfers" && (role === "Warehouse" || role === "Owner")) html += action("＋ Create Internal Transfer", "create-transfer") + action("Validate Transfer", "validate-transfer", "primary");
    if (page === "products" && role === "Owner") html += action("＋ Create Product Variant", "create-product", "primary");
    if (page === "returns") { if (role === "Warehouse" || role === "Owner") html += action("＋ Inspect Customer Return", "create-return", "primary"); if (role === "Finance" || role === "Owner") html += action("Post Credit Note", "post-return"); }
    if (page === "leads" && (role === "Sales" || role === "Owner")) html += action("＋ Create Lead", "create-lead", "primary") + action("Update Lead Stage", "update-lead") + action("Create Quotation from Lead", "create-quote");
    if (page === "quotations" && (role === "Sales" || role === "Owner")) html += action("Convert Quotation to SO", "convert-quote", "primary");
    if (page === "dashboard" && role === "Owner") html += action("Reset Baseline (Owner)", "reset-seed");
    if (html) $("#actions").innerHTML += `<div class="toolbar workflow-actions">${html}</div>`;
  }
  function addListToolbar(page) {
    const tableEl = $("#pageContent .table-wrap");
    if (!tableEl || page === "dashboard" || page === "stock") return;
    const original = tableEl.outerHTML;
    const toolbar = document.createElement("div");
    toolbar.className = "panel workflow-toolbar";
    toolbar.innerHTML = `<div class="toolbar"><input id="docSearch" type="search" placeholder="Search documents..." aria-label="Search documents"><select id="groupBy"><option value="status">Group by Status</option><option value="customer">Group by Customer</option><option value="vendor">Group by Vendor</option></select><button class="btn active" data-view="list">List</button><button class="btn" data-view="kanban">Kanban</button><button class="btn" data-view="form">Form</button><button class="btn" data-view="activity">Activity</button></div><div class="view-slot">${original}</div>`;
    tableEl.replaceWith(toolbar);
    let selectedId = null;
    let searchTerm = "";
    const slot = toolbar.querySelector(".view-slot");
    const freshTable = () => { const holder=document.createElement("div"); holder.innerHTML=original; return holder; };
    const bindRows = () => {
      const headers=[...slot.querySelectorAll("thead th")].map(x=>x.textContent.trim().toLowerCase());
      const idIndex=headers.indexOf("id");
      const rows=[...slot.querySelectorAll("tbody tr")];
      rows.forEach(row => {
        row.style.display=row.textContent.toLowerCase().includes(searchTerm) ? "" : "none";
        row.addEventListener("click", () => {
          rows.forEach(other=>other.classList.remove("workflow-selected"));
          row.classList.add("workflow-selected");
          const keyIndex=idIndex>=0?idIndex:0;
          const rawKey=row.cells[keyIndex]?.textContent.trim();
          selectedId=idIndex>=0?Number(rawKey):(rawKey||null);
        });
      });
    };
    bindRows();
    toolbar.querySelector("#docSearch").addEventListener("input", e => { searchTerm=e.target.value.toLowerCase(); bindRows(); });
    toolbar.querySelectorAll("[data-view]").forEach(btn => btn.addEventListener("click", () => {
      toolbar.querySelectorAll("[data-view]").forEach(b => b.classList.toggle("active", b===btn));
      if (btn.dataset.view === "list") { slot.innerHTML=original; bindRows(); return; }
      if (btn.dataset.view === "activity") { slot.innerHTML=`<div class="empty">Gunakan Audit Log untuk melihat actor, timestamp, action, dan reference yang tersedia sesuai role.</div>`; return; }
      if (btn.dataset.view === "form") {
        if (!selectedId) { slot.innerHTML=`<div class="empty">Pilih satu baris pada List View terlebih dahulu, lalu buka Form View.</div>`; return; }
        const kind={sales:"sales",purchase:"purchase",deliveries:"deliveries",receipts:"receipts",invoices:"invoices",bills:"bills",transfers:"transfers",returns:"returns",journals:"journals",leads:"leads",quotations:"quotations",audit:"audit"}[page];
        slot.innerHTML=`<div class="empty">Memuat detail dokumen…</div>`;
        const detailPath=["customers","products"].includes(page)?`/masters/${page}/${encodeURIComponent(selectedId)}`:`/documents/${kind}/${selectedId}`;
        api(detailPath).then(doc=>{
          const entries=Object.entries(doc).filter(([key])=>key!=="lines"&&key!=="credit_note");
          const fields=entries.map(([key,value])=>`<div class="detail-field"><small>${esc(key.replaceAll("_"," "))}</small><b>${esc(value??"—")}</b></div>`).join("");
          const lineTable=doc.lines?.length?`<h4>Document Lines</h4>${table(doc.lines)}`:"";
          const credit=doc.credit_note&&Object.keys(doc.credit_note).length?`<h4>Related Credit Note</h4>${table([doc.credit_note])}`:"";
          const related=doc.related_docs?.length?`<h4>Related Documents / Smart Links</h4><div class="related-doc-list">${doc.related_docs.map(x=>["reservation","credit-note"].includes(x.kind)?`<span class="related-doc"><b>${esc(x.relation)}</b> · ${esc(x.number)} · ${esc(x.status)}</span>`:`<button class="btn related-doc" data-related-kind="${esc(x.kind)}" data-related-id="${esc(x.id)}"><b>${esc(x.relation)}</b> · ${esc(x.number)} · ${esc(x.status)} ↗</button>`).join("")}</div>`:"";
          slot.innerHTML=`<div class="panel document-form"><div class="detail-grid">${fields}</div>${lineTable}${credit}${related}</div>`;
        }).catch(err=>{slot.innerHTML=`<div class="notice error">${esc(err.message)}</div>`;});
        return;
      }
      const source=freshTable();
      const headers=[...source.querySelectorAll("thead th")].map(x=>x.textContent.toLowerCase());
      const selectedGroup=toolbar.querySelector("#groupBy")?.value||"status";
      const groupIndex=Math.max(0,headers.indexOf(selectedGroup));
      const groups=new Map();
      [...source.querySelectorAll("tbody tr")].filter(row=>row.textContent.toLowerCase().includes(searchTerm)).forEach(row=>{
        const cells=[...row.cells];const key=cells[groupIndex]?.textContent.trim()||"Other";
        if(!groups.has(key))groups.set(key,[]);groups.get(key).push(row.innerText);
      });
      const grid=document.createElement("div");grid.className="kanban-grid";
      for(const [key,cards] of groups){const col=document.createElement("section");col.className="kanban-col";col.innerHTML=`<h4>${esc(key)} <small>${cards.length}</small></h4>`+cards.map(card=>`<article class="kanban-card">${esc(card.replace(/\s+/g," · "))}</article>`).join("");grid.append(col);}
      slot.replaceChildren(grid);
    }));
  }
  const baseOpenCreate = window.openCreate;
  window.openCreate = async function(type) {
    if (type !== "purchase") return baseOpenCreate(type);
    const [vendors, products] = await Promise.all([api("/masters/vendors"), api("/masters/products")]);
    openModal("New RFQ / Purchase Order", `<div class="form-grid"><div><label>Vendor</label><select id="vendor">${vendors.map(v=>`<option value="${esc(v.code)}">${esc(v.code)} · ${esc(v.name)}</option>`).join("")}</select></div><div><label>Product Variant (vendor pricelist)</label><select id="sku"></select></div><div><label>Quantity</label><input id="qty" type="number" value="1" min="1"></div></div>`, async m => {
      const vendor=m.querySelector("#vendor").value; const product=products.find(p=>p.sku===m.querySelector("#sku").value);
      if(!product)throw new Error("Vendor belum memiliki product pricelist.");
      await send("/purchase-orders","POST",{vendor_code:vendor,lines:[{sku:product.sku,quantity:Number(m.querySelector("#qty").value)}]});
    });
    const modal=document.querySelector(".modal-backdrop:last-child");
    const vendorSelect=modal.querySelector("#vendor"), skuSelect=modal.querySelector("#sku");
    const update=()=>{ const v=vendorSelect.value; skuSelect.innerHTML=products.filter(p=>p.default_vendor===v).map(p=>`<option value="${esc(p.sku)}">${esc(p.sku)} · ${esc(p.name)} (${esc(p.size||"")}) · ${fmt(p.standard_cost)}</option>`).join(""); };
    vendorSelect.addEventListener("change",update); update();
  };
  async function runWorkflow(name) {
    try {
      if (name === "create-sales") { await openCreate("sales"); return; }
      if (name === "create-po") { await openCreate("purchase"); return; }
      if (name === "create-transfer") { await openCreate("transfers"); return; }
      if (name === "create-product") {
        const sku=prompt("Variant SKU unik (contoh BVG-750-LEM):");if(!sku)return;
        const nameValue=prompt("Nama produk:");if(!nameValue)return;
        const size=prompt("Ukuran:");if(!size)return;
        const color=prompt("Warna / rasa:","Original");if(color===null)return;
        const unit=prompt("Unit (botol/kaleng/pak):","botol");if(!unit)return;
        const vendor=prompt("Default Vendor (V01-V04):","V01");if(!vendor)return;
        const price=Number(prompt("Sales Price (IDR):","15000"));
        const cost=Number(prompt("Standard Cost (IDR):","9000"));
        await send("/products","POST",{sku,name:nameValue,size,color,unit,default_vendor:vendor,sales_price:price,standard_cost:cost});
      }
      if (name === "validate-transfer") { const id=askId("Validate internal transfer"); if(id===null)return; await send(`/transfers/${id}/validate`); }
      else if (name === "confirm-so") { const id=askId("Confirm Sales Order"); if(id===null)return; await send(`/sales-orders/${id}/confirm`); }
      else if (name === "create-delivery") {
        const id=askId("Create Delivery from confirmed SO"); if(id===null)return;
        const doc=await api(`/documents/sales/${id}`); const lines=doc.lines||[];
        const quantities={}; for(const line of lines){ const n=prompt(`Qty delivery untuk ${line.sku} (ordered ${line.quantity}; 0 untuk skip):`,String(line.quantity)); if(n===null)return; const q=Number(n); if(!Number.isSafeInteger(q)||q<0)throw new Error("Quantity delivery tidak valid."); if(q)quantities[line.sku]=q; }
        await send(`/sales-orders/${id}/delivery`,"POST",{quantities});
      }
      else if (name === "validate-delivery") { const id=askId("Validate Delivery Order"); if(id===null)return; await send(`/deliveries/${id}/validate`); }
      else if (name === "confirm-po") { const id=askId("Request / Confirm Purchase Order"); if(id===null)return; await send(`/purchase-orders/${id}/confirm`); }
      else if (name === "approve-po") { const id=askId("Owner approval for Pending Approval PO"); if(id===null)return; await send(`/purchase-orders/${id}/approve`); }
      else if (name === "create-receipt") {
        const id=askId("Create Receipt from Confirmed PO"); if(id===null)return; const doc=await api(`/documents/purchase/${id}`); const lines=doc.lines||[];
        const receiptLines=[]; for(const line of lines){ const n=prompt(`Barang diterima untuk ${line.sku} (PO ${line.quantity}; 0 untuk skip):`,String(line.quantity)); if(n===null)return; const q=Number(n); if(!Number.isSafeInteger(q)||q<0)throw new Error("Received quantity tidak valid."); if(q)receiptLines.push({sku:line.sku,received_qty:q}); }
        if(!receiptLines.length)throw new Error("Isi minimal satu received quantity.");
        await send(`/purchase-orders/${id}/receipt`,"POST",{warehouse_code:"WH-PKU",lines:receiptLines});
      }
      else if (name === "quality-check") {
        const id=askId("Quality Check on Receipt"); if(id===null)return; const doc=await api(`/documents/receipts/${id}`);
        for(const line of (doc.lines||[])){ const pass=prompt(`${line.sku}: jumlah PASS dari ${line.received_qty}:`,String(line.received_qty)); if(pass===null)return; const fail=prompt(`${line.sku}: jumlah FAIL:`,String(line.received_qty-Number(pass))); if(fail===null)return; const reason=Number(fail)>0?prompt("Alasan barang Fail:","Segel rusak"):""; if(reason===null)return; await send(`/receipts/${id}/quality-check`,"POST",{sku:line.sku,accepted_qty:Number(pass),rejected_qty:Number(fail),quality_reason:reason}); }
      }
      else if (name === "validate-receipt") { const id=askId("Validate Receipt after Quality Check"); if(id===null)return; await send(`/receipts/${id}/validate`); }
      else if (name === "create-bill") {
        const id=askId("Create Vendor Bill from validated Receipt"); if(id===null)return;
        const receipt=await api(`/documents/receipts/${id}`);
        const requested=[];
        for(const line of (receipt.lines||[])){
          const defaultQty=Number(line.accepted_qty||0);
          const raw=prompt(`${line.sku}: quantity pada tagihan vendor (accepted ${defaultQty}; isi ${line.received_qty} untuk simulasi selisih T-24):`,String(defaultQty));
          if(raw===null)return;
          const qty=Number(raw);if(!Number.isSafeInteger(qty)||qty<0)throw new Error("Vendor Bill quantity harus bilangan bulat >= 0.");
          if(qty>0)requested.push({sku:line.sku,quantity:qty});
        }
        await send(`/vendor-bills/from-receipt/${id}`,"POST",{lines:requested});
      }
      else if (name === "create-invoice") { const id=askId("Create Customer Invoice from SO"); if(id===null)return; await send(`/invoices/from-order/${id}`); }
      else if (name === "post-invoice") { const id=askId("Post Customer Invoice"); if(id===null)return; await send(`/invoices/${id}/post`); }
      else if (name === "post-bill") { const id=askId("Post Vendor Bill"); if(id===null)return; await send(`/vendor-bills/${id}/post`); }
      else if (name === "customer-payment" || name === "vendor-payment") {
        const id=askId(name==="customer-payment"?"Customer Invoice database ID":"Vendor Bill database ID"); if(id===null)return;
        const amount=Number(prompt("Jumlah pembayaran (IDR):","40000")); if(!Number.isSafeInteger(amount)||amount<=0)throw new Error("Jumlah pembayaran harus positif.");
        await send("/payments","POST",{document_type:name==="customer-payment"?"customer":"vendor",document_id:id,amount,idempotency_key:(crypto.randomUUID?crypto.randomUUID():`${Date.now()}-${Math.random()}`)});
      }
      else if (name === "create-return") {
        const id=askId("Customer Invoice database ID untuk retur"); if(id===null)return; const doc=await api(`/documents/invoices/${id}`); const lines=doc.lines||[];
        if(!lines.length)throw new Error("Invoice tidak memiliki line.");
        const sku=prompt(`SKU yang diretur:\n${lines.map(x=>`${x.sku} · ${x.quantity}`).join("\n")}`,lines[0].sku); if(sku===null)return;
        const qty=Number(prompt("Jumlah retur:","1")); if(!Number.isSafeInteger(qty)||qty<=0)throw new Error("Quantity retur tidak valid.");
        const saleable=confirm("Barang retur layak jual dan boleh masuk kembali ke stok?"); const reason=saleable?"":prompt("Alasan barang tidak layak jual:","Kemasan rusak"); if(reason===null)return;
        await send("/returns","POST",{invoice_id:id,sku,quantity:qty,inspection_status:saleable?"Saleable":"Rejected",quality_reason:reason,idempotency_key:(crypto.randomUUID?crypto.randomUUID():`${Date.now()}-${Math.random()}`)});
      }
      else if (name === "post-return") { const id=askId("Post Credit Note for Received Return"); if(id===null)return; await send(`/returns/${id}/validate`); }
      else if (name === "create-lead") {
        const title=prompt("Nama / deskripsi Lead:"); if(!title)return; const customer=prompt("Customer code (C01-C06), boleh kosong:",""); await send("/leads","POST",{title,customer_code:customer||null});
      }
      else if (name === "update-lead") {
        const id=askId("Lead database ID"); if(id===null)return; const stage=prompt("Stage: New, Qualified, Won, Lost","Qualified"); if(!stage)return; await send(`/leads/${id}/stage`,"POST",{stage});
      }
      else if (name === "create-quote") {
        const id=askId("Lead database ID"); if(id===null)return; const doc=await api(`/documents/leads/${id}`); const customer=doc.customer_code||prompt("Customer code:","C03"); if(!customer)return;
        const sku=prompt("SKU produk:","BVG-250-LEM"); if(!sku)return; const qty=Number(prompt("Quantity:","8")); if(!Number.isSafeInteger(qty)||qty<=0)throw new Error("Quantity tidak valid."); const discount=Number(prompt("Discount %:","0"));
        await send(`/leads/${id}/quotations`,"POST",{customer_code:customer,discount_pct:discount,lines:[{sku,quantity:qty}]});
      }
      else if (name === "convert-quote") { const id=askId("Quotation database ID"); if(id===null)return; await send(`/quotations/${id}/convert`); }
      else if (name === "reset-seed") { if(!confirm("PERINGATAN: semua transaksi uji akan dihapus dan baseline dikembalikan. Lanjutkan?"))return; await send("/seed/reset"); }
      await show(currentPage); notice("Aksi berhasil diproses. Periksa status dan dokumen terkait.");
    } catch (err) { notice(err.message || "Workflow gagal diproses.", true); }
  }
  document.addEventListener("click", async e => {
    const related=e.target.closest("[data-related-kind]");
    if(related){
      e.preventDefault();
      const map={sales:"sales",purchase:"purchase",deliveries:"deliveries",receipts:"receipts",invoices:"invoices",bills:"bills",transfers:"transfers",returns:"returns",quotations:"quotations",leads:"leads","credit-notes":"returns"};
      const page=map[related.dataset.relatedKind];
      if(!page)return;
      await window.show(page);
      const row=[...document.querySelectorAll("#pageContent tbody tr")].find(r=>Number(r.cells[0]?.textContent)===Number(related.dataset.relatedId));
      if(row){row.click();document.querySelector('#pageContent [data-view="form"]')?.click();}
      return;
    }
    const btn=e.target.closest("[data-workflow]");
    if(btn){e.preventDefault();if(btn.disabled)return;btn.disabled=true;try{await runWorkflow(btn.dataset.workflow);}finally{btn.disabled=false;}}
  });
  window.show = async function(page) {
    await baseShow(page);
    addActions(page);
    addListToolbar(page);
  };
})();
