from functools import wraps
from flask import session, jsonify

# API-level permissions are authoritative; hiding a navigation item is not security.
PERMISSIONS = {
    "Owner": {"*"},
    "Sales": {
        "dashboard.view", "crm.view", "crm.create", "crm.update",
        "sales.view", "sales.create", "sales.confirm", "invoicing.view", "contacts.view",
        "products.view", "inventory.view", "delivery.view",
    },
    "Warehouse": {
        "dashboard.view", "contacts.view", "products.view", "inventory.view", "sales.view", "purchase.view",
        "delivery.view", "delivery.create", "delivery.validate", "invoicing.view",
        "transfer.view", "transfer.create", "transfer.validate",
        "receipt.view", "receipt.create", "receipt.validate", "returns.view",
        "returns.create",
    },
    "Procurement": {
        "dashboard.view", "contacts.view", "products.view", "purchase.view",
        "purchase.create", "purchase.confirm", "receipt.view", "bills.view",
    },
    "Quality": {
        "dashboard.view", "contacts.view", "products.view", "receipt.view",
        "quality.view", "quality.check", "returns.view",
    },
    "Finance": {
        "dashboard.view", "contacts.view", "products.view", "sales.view",
        "purchase.view", "delivery.view", "receipt.view", "invoicing.view",
        "invoicing.post", "bills.view", "bills.post", "payments.view",
        "payments.create", "accounting.view", "accounting.post", "reports.view",
        "returns.view", "returns.validate", "crm.view",
    },
}


def allowed(permission):
    role = session.get("user", {}).get("role")
    return role == "Owner" or permission in PERMISSIONS.get(role, set())


def require(permission):
    def deco(fn):
        @wraps(fn)
        def wrapped(*args, **kwargs):
            if not session.get("user_id"):
                return jsonify({"error": "Authentication required"}), 401
            if not allowed(permission):
                return jsonify({"error": "Akses ditolak untuk role ini", "required_permission": permission}), 403
            return fn(*args, **kwargs)
        return wrapped
    return deco
